package com.example.uhbapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
