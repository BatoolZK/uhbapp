import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AcademicRecordsPage extends StatefulWidget {
  @override
  _AcademicRecordsPageState createState() => _AcademicRecordsPageState();
}

class _AcademicRecordsPageState extends State<AcademicRecordsPage> {
  final List<List<String>> courseNames = [
    ["MATH 101", "PHYS 101", "ENGL 101", "CHEM 111", "IAS 111", "PE 101"],
    ["MATH 102", "PHYS 102", "ENGL 102", "CSE 102", "IAS 101", "PE 102"],
    ["EE 200", "CSE 201", "ENGL 214", "MATH 201", "IAS 212"],
    ["SWE 205", "SWE 215", "CSE 202", "BIOL 233", "CSE 253"],
    ["SWE 326", "CSE 333", "CSE 324", "SWE 316", "IAS 201"],
    ["STAT 319", "CSE 343", "CSE 353", "SWE 312", "SWE 387", "IAS 301", "SWE 399"],
    ["XXXXXX", "SWE 417", "CSE 335", "CSE 309", "SWE 363", "IAS 322"],
    ["CSE 401", "XXXXXX", "XXXXXX", "SWE 418", "GSXXX"],
  ];

  Map<String, double> courseGrades = {};

  @override
  void initState() {
    super.initState();
    _fetchGrades();
  }

  Future<void> _fetchGrades() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      FirebaseFirestore.instance
          .collection('student_courses')
          .where('userId', isEqualTo: user.uid)
          .get()
          .then((snapshot) {
        Map<String, double> grades = {};
        for (var doc in snapshot.docs) {
          String course =
              doc.data()['courseCode'] as String? ?? 'Unknown Course';
          double grade = (doc.data()['grade'] as num?)?.toDouble() ?? 0.0;

          if (!grades.containsKey(course) || grade > grades[course]!) {
            grades[course] = grade;
          }
        }
        setState(() {
          courseGrades = grades;
        });
      });
    }
  }

  Color _getColorForCourse(String course) {
    print("-----------------");
    print(courseGrades[course]);
    double? grade = courseGrades[course];
    return (grade != null && grade > 60) ? Colors.green : Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student Academic Plan'),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columnSpacing: 12,
          border: TableBorder.all(color: Colors.grey),
          columns: [
            DataColumn(label: Text('Level')),
            for (int i = 0; i < 6; i++)
              DataColumn(label: Text('Course ${i + 1}')),
          ],
          rows: List<DataRow>.generate(
            8,
            (levelIndex) => DataRow(
              cells: <DataCell>[
                DataCell(Text('Level ${levelIndex + 1}')),
                ...List<DataCell>.generate(
                  6,
                  (courseIndex) {
                    final String course =
                        courseNames[levelIndex].length > courseIndex
                            ? courseNames[levelIndex][courseIndex]
                            : '';
                    return DataCell(
                      Text(
                        course,
                        style: TextStyle(
                          color: _getColorForCourse(course),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
