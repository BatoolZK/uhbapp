import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uhbapp/CourseAssignmentPage.dart';

class AdminAcademicRecordsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin: Student Academic Plan Assignment'),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('users')
                 .where('type', isEqualTo: 'student').snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) return CircularProgressIndicator();

          var students = snapshot.data!.docs;
          return ListView.builder(
            itemCount: students.length,
            itemBuilder: (context, index) {
              var student = students[index];
              return ListTile(
                title: Text(student['name']),
                subtitle: Text('ID: ${student.id}'),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => CourseAssignmentPage(studentId: student.id, studentName: student['name']),
                  ));
                },
              );
            },
          );
        },
      ),
    );
  }
}
 

