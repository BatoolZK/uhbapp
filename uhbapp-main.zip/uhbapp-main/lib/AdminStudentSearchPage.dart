import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uhbapp/StudentDetailsPage.dart';

class AdminStudentSearchPage extends StatefulWidget {
  @override
  _AdminStudentSearchPageState createState() => _AdminStudentSearchPageState();
}

class _AdminStudentSearchPageState extends State<AdminStudentSearchPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> students = [];
  List<Map<String, dynamic>> filteredStudents = [];

  @override
  void initState() {
    super.initState();
    fetchStudents();
    _searchController.addListener(_filterStudents);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> fetchStudents() async {
    var studentSnapshot = await _firestore
        .collection('users')
        .where('type', isEqualTo: 'student')
        .get();

    List<Map<String, dynamic>> tempStudents = [];
    for (var doc in studentSnapshot.docs) {
      var data = doc.data();
      data['id'] = doc.id;
      tempStudents.add(data);
    }

    setState(() {
      students = tempStudents;
      filteredStudents = tempStudents;
    });
  }

  void _filterStudents() {
    String query = _searchController.text.toLowerCase();
    List<Map<String, dynamic>> tempFilteredStudents = [];
    if (query.isNotEmpty) {
      tempFilteredStudents = students.where((student) {
        String name =
            '${student['firstName']} ${student['lastName']}'.toLowerCase();
        String email = student['email'].toLowerCase();
        return name.contains(query) || email.contains(query);
      }).toList();
    } else {
      tempFilteredStudents = students;
    }
    setState(() {
      filteredStudents = tempFilteredStudents;
    });
  }

  void _navigateToStudentDetails(BuildContext context, Map<String, dynamic> student) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => StudentDetailsPage(student: student),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student Search'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search Students',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: filteredStudents.length,
                itemBuilder: (context, index) {
                  var student = filteredStudents[index];
                  return Card(
                    margin: EdgeInsets.all(8),
                    child: ListTile(
                      title: Text('${student['firstName']} ${student['lastName']}'),
                      subtitle: Text(student['email']),
                      onTap: () => _navigateToStudentDetails(context, student),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
