import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uhbapp/TeacherAssignedCoursesPage.dart';
 
class AdminTeacherSearchPage extends StatefulWidget {
  @override
  _AdminTeacherSearchPageState createState() => _AdminTeacherSearchPageState();
}

class _AdminTeacherSearchPageState extends State<AdminTeacherSearchPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> teachers = [];
  List<Map<String, dynamic>> filteredTeachers = [];

  @override
  void initState() {
    super.initState();
    fetchTeachers();
    _searchController.addListener(_filterTeachers);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> fetchTeachers() async {
    var teacherSnapshot = await _firestore
        .collection('users')
        .where('type', isEqualTo: 'teacher')
        .get();

    List<Map<String, dynamic>> tempTeachers = [];
    for (var doc in teacherSnapshot.docs) {
      tempTeachers.add(doc.data());
    }

    setState(() {
      teachers = tempTeachers;
      filteredTeachers = tempTeachers;
    });
  }

  void _filterTeachers() {
    String query = _searchController.text.toLowerCase();
    List<Map<String, dynamic>> tempFilteredTeachers = [];
    if (query.isNotEmpty) {
      tempFilteredTeachers = teachers.where((teacher) {
        String name =
            '${teacher['firstName']} ${teacher['lastName']}'.toLowerCase();
        String email = teacher['email'].toLowerCase();
        return name.contains(query) || email.contains(query);
      }).toList();
    } else {
      tempFilteredTeachers = teachers;
    }
    setState(() {
      filteredTeachers = tempFilteredTeachers;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Teacher Search'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search Teachers',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: filteredTeachers.length,
                itemBuilder: (context, index) {
                  var teacher = filteredTeachers[index];
                  return Card(
                    margin: EdgeInsets.all(8),
                    child: ListTile(
                      title: Text('${teacher['firstName']} ${teacher['lastName']}'),
                      subtitle: Text(teacher['email']),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => TeacherAssignedCoursesPage(
                              teacherEmail: teacher['email'],
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
