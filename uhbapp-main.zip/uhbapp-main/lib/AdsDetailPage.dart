import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';  

class AdsDetailPage extends StatelessWidget {
  final DateFormat dateFormatter = DateFormat('yyyy-MM-dd');  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Available Ads'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Container(
        color: Colors.blue.shade50,
        child: StreamBuilder(
          stream: FirebaseFirestore.instance.collection('ads')
                    .orderBy('date', descending: true)  
                    .snapshots(),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasError) {
              return Text('Something went wrong: ${snapshot.error}');
            }

            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }

            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                var ad = snapshot.data!.docs[index];
                return AdCard(ad: ad, dateFormatter: dateFormatter);
              },
            );
          },
        ),
      ),
    );
  }
}

class AdCard extends StatelessWidget {
  final QueryDocumentSnapshot ad;
  final DateFormat dateFormatter;  

  AdCard({required this.ad, required this.dateFormatter});

  @override
  Widget build(BuildContext context) {
    Timestamp timestamp = ad['date'] as Timestamp; 

    String formattedDate = dateFormatter.format(timestamp.toDate()); 


    return Card(
      elevation: 5,
      margin: EdgeInsets.all(10),
      child: Column(
        children: [
          ad['imageUrl'] != null
            ? Image.network(
                ad['imageUrl'],
                width: double.infinity,
                height: 200,
                fit: BoxFit.cover,
              )
            : Container(height: 200, color: Colors.grey.shade300, alignment: Alignment.center, child: Text('No Image Available')),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ad['title'],
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue.shade700,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  ad['content'],
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(height: 8),
                Text(
                  'Date: $formattedDate',  

                  style: TextStyle(color: Colors.grey.shade600),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
