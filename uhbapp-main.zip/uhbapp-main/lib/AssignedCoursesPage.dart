import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uhbapp/CourseStudents.dart';
import 'CourseExcusesPage.dart';

class AssignedCoursesPage extends StatefulWidget {
  @override
  _AssignedCoursesPageState createState() => _AssignedCoursesPageState();
}

class _AssignedCoursesPageState extends State<AssignedCoursesPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<CourseAssignment>> fetchAssignedCourses() async {
    User? user = _auth.currentUser;
    List<CourseAssignment> courses = [];
    Set<String> courseCodes = Set();

    if (user != null) {
      var snapshots = await _firestore
          .collection('courses')
          .where('instructor', isEqualTo: user.email)
          .get();

      for (var doc in snapshots.docs) {
        var course = CourseAssignment.fromFirestore(doc);
        if (!courseCodes.contains(course.code)) {
          courses.add(course);
          courseCodes.add(course.code);
        }
      }
    }
    return courses;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Assigned Courses'),
        backgroundColor: Colors.deepPurple,
      ),
      body: FutureBuilder<List<CourseAssignment>>(
        future: fetchAssignedCourses(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error fetching courses'));
          } else if (snapshot.data!.isEmpty) {
            return Center(child: Text('No courses assigned yet'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                var course = snapshot.data![index];
                return Card(
                  margin: EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(course.name),
                    subtitle: Text(course.code),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.people, color: Colors.blue),
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    CourseStudentsPage(courseCode: course.code)),
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.report, color: Colors.red),
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    CourseExcusesPage(courseCode: course.code)),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}

class CourseAssignment {
  final String code;
  final String name;
  final String instructor;

  CourseAssignment(
      {required this.code, required this.name, required this.instructor});

  factory CourseAssignment.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return CourseAssignment(
      code: data['code'],
      name: data['name'],
      instructor: data['instructor'],
    );
  }
}
