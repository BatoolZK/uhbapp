import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class AttendancePage extends StatefulWidget {
  @override
  _AttendancePageState createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  List<Map<String, dynamic>> _attendanceRecords = [];

  @override
  void initState() {
    super.initState();
    _fetchAttendanceData();
  }

  Future<void> _fetchAttendanceData() async {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      FirebaseFirestore.instance
        .collection('excuses')
        .where('userId', isEqualTo: user.uid)
        .orderBy('date')
        .get()
        .then((snapshot) {
          List<Map<String, dynamic>> records = [];
          for (var doc in snapshot.docs) {
            Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
            DateTime date = DateTime.parse(data['date']);
            data['formattedDate'] = DateFormat('yyyy-MM-dd – kk:mm').format(date);
            records.add(data);
          }
          setState(() {
            _attendanceRecords = records;
          });
        });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Details'),
      ),
      body: ListView.builder(
        itemCount: _attendanceRecords.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              leading: Icon(Icons.calendar_today),
              title: Text(_attendanceRecords[index]['courseCode']),
              subtitle: Text("${_attendanceRecords[index]['formattedDate']} - ${_attendanceRecords[index]['reason']}"),
              isThreeLine: true,
              trailing: _attendanceRecords[index]['name'].startsWith('Miss') ? Icon(Icons.missed_video_call) : null,
            ),
          );
        },
      ),
    );
  }
}
