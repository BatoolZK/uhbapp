import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uhbapp/ChatScreen.dart';

class ChatHomePage extends StatefulWidget {
  ChatHomePage({Key? key}) : super(key: key);

  @override
  State<ChatHomePage> createState() => _ChatHomePageState();
}

class _ChatHomePageState extends State<ChatHomePage> {
  List<Map<String, dynamic>> _chats = [];
  String? _currentUserId;

  @override
  void initState() {
    super.initState();
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      _currentUserId = user.uid;
      _fetchChats();
    }
  }

  void _fetchChats() async {
    if (_currentUserId == null) return;

    FirebaseFirestore.instance
        .collection('messages')
        .where('receiverId', isEqualTo: _currentUserId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .listen((snapshot) {
          Map<String, Future<Map<String, dynamic>>> mostRecentMessages = {};

          for (var doc in snapshot.docs) {
            var data = doc.data() as Map<String, dynamic>;
            String senderId = data['senderId'] as String;

            // Only fetch the latest message per sender
            if (!mostRecentMessages.containsKey(senderId)) {
              data['createdAt'] = DateTime.parse(data['createdAt'] as String).toIso8601String();

              // Fetch sender details from the users collection
              mostRecentMessages[senderId] = FirebaseFirestore.instance
                  .collection('users')
                  .doc(senderId)
                  .get()
                  .then((userDoc) {
                    if (userDoc.exists) {
                      var userData = userDoc.data() as Map<String, dynamic>;
                      String senderName = userData['firstName'] + ' ' + userData['lastName'];
                      if (userData.containsKey('studentID')) {
                        senderName += ' (${userData['studentID']})';
                      }
                      data['senderName'] = senderName;
                    } else {
                      data['senderName'] = 'Unknown Sender';
                    }
                    return data;
                  });
            }
          }

          Future.wait(mostRecentMessages.values).then((allChats) {
            setState(() {
              _chats = allChats.cast<Map<String, dynamic>>();
            });
          });
        });
  }

  void _openChatPage(String otherUserId, String otherUserName) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatPage(userId: otherUserId, userName: otherUserName),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat'),
      ),
      body: ListView.builder(
        itemCount: _chats.length,
        itemBuilder: (context, index) {
          var chat = _chats[index];
          return ListTile(
            title: Text(chat['senderName'] as String? ?? 'Unknown Sender'),
            subtitle: Text(chat['text'] as String? ?? 'No message'),
            trailing: Text(chat['createdAt'] as String? ?? 'No timestamp'),
            onTap: () => _openChatPage(chat['senderId'] as String, chat['senderName'] as String? ?? 'Unknown'),
          );
        },
      ),
    );
  }
}
