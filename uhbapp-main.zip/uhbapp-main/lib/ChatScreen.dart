import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
 
class ChatPage extends StatefulWidget {
  final String? userName;
  final String userId;   

  const ChatPage({Key? key, this.userName, required this.userId}) : super(key: key);

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  List<ChatMessage> _messages = [];
  final TextEditingController _controller = TextEditingController();
  String? _currentUserId;

  @override
  void initState() {
    super.initState();
    _initializeUser();
  }

  void _initializeUser() {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        _currentUserId = user.uid;
      });
      _loadMessages();
    } else {
    }
  }

void _loadMessages() {
  if (_currentUserId == null) return;

  FirebaseFirestore.instance
      .collection('messages')
      .where('senderId', isEqualTo: _currentUserId)
      .where('receiverId', isEqualTo: widget.userId)
      .orderBy('createdAt', descending: true)
      .snapshots().listen(_handleMessagesSnapshot);

  FirebaseFirestore.instance
      .collection('messages')
      .where('receiverId', isEqualTo: _currentUserId)
      .where('senderId', isEqualTo: widget.userId)
      .orderBy('createdAt', descending: true)
      .snapshots().listen(_handleMessagesSnapshot);
}

void _handleMessagesSnapshot(QuerySnapshot snapshot) {
  List<ChatMessage> newMessages = snapshot.docs.map((doc) => ChatMessage.fromJson(doc.data() as Map<String, dynamic>)).toList();


  Set<String> existingIds = _messages.map((m) => m.id).toSet();
  newMessages.retainWhere((m) => !existingIds.contains(m.id));

  setState(() {
    _messages.addAll(newMessages);
    _messages.sort((b, a) => a.createdAt.compareTo(b.createdAt));
  });
}


  void _handleSendPressed() {
    if (_controller.text.isNotEmpty && _currentUserId != null) {
      final message = ChatMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        text: _controller.text,
        createdAt: DateTime.now(),
        senderId: _currentUserId!,
        receiverId: widget.userId
      );

      FirebaseFirestore.instance.collection('messages').doc(message.id).set(message.toJson());
      _controller.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.userName ?? 'Chat'),
        actions: [
           
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                bool isMine = message.senderId == _currentUserId;
                return ListTile(
                  title: Align(
                    alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: isMine ? Colors.blue[100] : Colors.grey[300],
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(message.text),
                    ),
                  ),
                  subtitle: Align(
                    alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
                    child: Text(message.createdAt.toString(), style: TextStyle(fontSize: 10)),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      labelText: 'Type a message...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _handleSendPressed,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

 
class ChatMessage {
  final String id;
  final String text;
  final DateTime createdAt;
  final String senderId;
  final String receiverId;

  ChatMessage({
    required this.id, 
    required this.text, 
    required this.createdAt, 
    required this.senderId, 
    required this.receiverId
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'text': text,
    'createdAt': createdAt.toIso8601String(),
    'senderId': senderId,
    'receiverId': receiverId,
  };

  static ChatMessage fromJson(Map<String, dynamic> json) => ChatMessage(
    id: json['id'],
    text: json['text'],
    createdAt: DateTime.parse(json['createdAt']),
    senderId: json['senderId'],
    receiverId: json['receiverId'],
  );
}
