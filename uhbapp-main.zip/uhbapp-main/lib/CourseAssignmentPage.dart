import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CourseAssignmentPage extends StatefulWidget {
  final String studentId;
  final String studentName;

  const CourseAssignmentPage({Key? key, required this.studentId, required this.studentName}) : super(key: key);

  @override
  _CourseAssignmentPageState createState() => _CourseAssignmentPageState();
}

class _CourseAssignmentPageState extends State<CourseAssignmentPage> {
  final List<List<String>> courseNames = [
    ["MATH 101", "PHYS101", "ENGL101", "CHEM111", "IAS111", "PE101"],
    ["MATH102", "PHYS102", "ENGL102", "CSE102", "IAS101", "PE102"],
    ["EE200", "CSE201", "ENGL214", "MATH201", "IAS212"],
    ["SWE205", "SWE215", "CSE202", "BIOL233", "CSE253"],
    ["SWE326", "CSE333", "CSE324", "SWE316", "IAS201"],
    ["STAT319", "CSE343", "CSE353", "SWE312", "SWE387", "IAS301", "SWE399"],
    ["STAT319", "SWE417", "CSE335", "CSE309", "SWE363", "IAS322"],
    ["CSE401", "STAT319", "CSE309", "SWE418", "STAT319"],
  ];
  Map<String, dynamic> assignedCourses = {};

  @override
  void initState() {
    super.initState();
    _fetchAssignedCourses();
  }

  Future<void> _fetchAssignedCourses() async {
    var assignments = await FirebaseFirestore.instance
        .collection('studentCourses')
        .where('studentId', isEqualTo: widget.studentId)
        .get();

    Map<String, dynamic> tempAssigned = {};
    for (var doc in assignments.docs) {
      var data = doc.data();
      var course = data['course'] as String;
      tempAssigned[course] = {
        'docId': doc.id,
        'grade': data['grade'],
        'year': data['year']
      };
    }

    setState(() {
      assignedCourses = tempAssigned;
    });
  }

  Future<void> _toggleCourseAssignment(String course, int year) async {
    var courseData = assignedCourses[course];
    if (courseData != null && courseData['grade'] == null) {

      await FirebaseFirestore.instance.collection('studentCourses').doc(courseData['docId']).delete();
      setState(() {
        assignedCourses.remove(course);
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("$course unassigned successfully")));
    } else if (courseData == null || (courseData['grade'] != null && courseData['grade'] < 60)) {

      var docRef = await FirebaseFirestore.instance.collection('studentCourses').add({
        'studentId': widget.studentId,
        'course': course,
        'year': year,
        'assigned': DateTime.now(),
        'grade': null  
        
      });
      setState(() {
        assignedCourses[course] = {
          'docId': docRef.id,
          'grade': null,   
          'year': year
        };
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("$course assigned for year $year successfully")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Assign Courses for ${widget.studentName}'),
      ),
      body: ListView.builder(
        itemCount: courseNames.length,
        itemBuilder: (context, levelIndex) {
          return ExpansionTile(
            title: Text('Year ${levelIndex + 1} Courses'),
            children: courseNames[levelIndex].map<Widget>((course) {
              var courseData = assignedCourses[course];
              bool isAssigned = courseData != null;
              bool isReassignable = isAssigned && courseData['grade'] != null && courseData['grade'] < 60;
              bool isGradeRecorded = isAssigned && courseData['grade'] != null;
              return ListTile(
                title: Row(
                  children: [
                    Expanded(child: Text(course)),
                    if (isReassignable) ...[
                      Icon(Icons.warning, color: Colors.red),
                      Text(' R', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                    ]
                  ],
                ),
                trailing: isAssigned ? Icon(Icons.check, color: Colors.green) : null,
                onTap: (isAssigned && !isGradeRecorded) || (!isAssigned || isReassignable) ? () => _toggleCourseAssignment(course, levelIndex + 1) : null,
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
