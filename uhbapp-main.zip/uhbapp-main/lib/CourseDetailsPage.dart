import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'package:uhbapp/ChatScreen.dart';

class CourseDetailsPage extends StatefulWidget {
  final String courseCode;

  CourseDetailsPage({Key? key, required this.courseCode}) : super(key: key);

  @override
  _CourseDetailsPageState createState() => _CourseDetailsPageState();
}

class _CourseDetailsPageState extends State<CourseDetailsPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final ImagePicker _picker = ImagePicker();
  Map<String, dynamic> courseDetails = {};
  String teacherName = "";
  String teacherId = "";
  XFile? _imageFile;

  @override
  void initState() {
    super.initState();
    fetchCourseDetails();
  }

  Future<void> fetchCourseDetails() async {
    try {
      var courseData = await FirebaseFirestore.instance
          .collection('courses')
          .where('code', isEqualTo: widget.courseCode)
          .limit(1)
          .get();

      if (courseData.docs.isNotEmpty) {
        setState(() {
          courseDetails = courseData.docs.first.data();
        });

        String instructorEmail = courseData.docs.first.data()['instructor'];
        var instructorData = await FirebaseFirestore.instance
            .collection('users')
            .where('email', isEqualTo: instructorEmail)
            .limit(1)
            .get();

        if (instructorData.docs.isNotEmpty) {
          setState(() {
            teacherName = instructorData.docs.first.data()['firstName'] + " " + instructorData.docs.first.data()['lastName'];
            teacherId = instructorData.docs.first.id;
          });
        }
      }
    } catch (e) {
      print("Error fetching course and teacher details: $e");
    }
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _imageFile = pickedFile;
    });
  }

  Future<void> submitExcuse() async {
    TextEditingController excuseController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Submit Excuse for Absence'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: excuseController,
                decoration: InputDecoration(
                  hintText: 'Enter your excuse',
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: _pickImage,
                child: Text(_imageFile == null ? 'Pick Image' : 'Change Image'),
              ),
              _imageFile != null
                  ? Image.file(File(_imageFile!.path), height: 100)
                  : Container(),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text('Submit'),
              onPressed: () async {
                if (excuseController.text.isNotEmpty && _imageFile != null) {
                  String fileName = '${DateTime.now().millisecondsSinceEpoch}_${_imageFile!.path.split('/').last}';
                  UploadTask uploadTask = _storage.ref('excuses/$fileName').putFile(File(_imageFile!.path));
                  TaskSnapshot snapshot = await uploadTask;
                  String downloadUrl = await snapshot.ref.getDownloadURL();

                  await FirebaseFirestore.instance.collection('excuses').add({
                    'userId': _auth.currentUser?.uid,
                    'courseCode': widget.courseCode,
                    'excuse': excuseController.text,
                    'date': DateTime.now(),
                    'approved': null,
                    'imageUrl': downloadUrl,
                  });

                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Excuse submitted successfully')));
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content:
                          Text('Please provide an excuse and select an image')));
                }
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Course Details'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: courseDetails.isNotEmpty
          ? SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text("Course Code",
                      style: TextStyle(color: Colors.grey[600], fontSize: 16)),
                  Text("${courseDetails['code']}",
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.deepPurple)),
                  SizedBox(height: 20),
                  Text("Course Name",
                      style: TextStyle(color: Colors.grey[600], fontSize: 16)),
                  Text("${courseDetails['name']}",
                      style: TextStyle(fontSize: 20)),
                  SizedBox(height: 20),
                  Text("Instructor",
                      style: TextStyle(color: Colors.grey[600], fontSize: 16)),
                  Text("$teacherName",
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.teal)),
                  SizedBox(height: 20),
                  Text("Description",
                      style: TextStyle(color: Colors.grey[600], fontSize: 16)),
                  Text(
                      "${courseDetails['description'] ?? 'No description provided.'}",
                      style: TextStyle(fontSize: 18)),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: submitExcuse,
                    child: Text('Submit Excuse'),
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: Color.fromARGB(255, 196, 82, 196),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ChatPage(userId: teacherId)),
                      );
                    },
                    child: Text('Chat with Teacher'),
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: Colors.green,
                    ),
                  ),
                ],
              ),
            )
          : Center(child: CircularProgressIndicator()),
    );
  }
}
