import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CourseExcusesPage extends StatefulWidget {
  final String courseCode;

  CourseExcusesPage({Key? key, required this.courseCode}) : super(key: key);

  @override
  _CourseExcusesPageState createState() => _CourseExcusesPageState();
}

class _CourseExcusesPageState extends State<CourseExcusesPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  late Future<List<Excuse>> excusesFuture;

  @override
  void initState() {
    super.initState();
    excusesFuture = fetchExcusesForCourse();
  }

  Future<List<Excuse>> fetchExcusesForCourse() async {
    List<Excuse> excuses = [];
    var excusesQuery = await _firestore
        .collection('excuses')
        .where('courseCode', isEqualTo: widget.courseCode)
        .get();

    for (var doc in excusesQuery.docs) {
      var userData = await _firestore.collection('users').doc(doc.data()['userId']).get();
      String userName = userData.data()?['name'] ?? 'No Name';
      excuses.add(Excuse.fromFirestore(doc, userName));
    }
    return excuses;
  }

void confirmAction(String docId, bool approved, String excuseText) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Confirm Action'),
        content: SingleChildScrollView( 
          child: ListBody(
            children: <Widget>[
              Text('Are you sure you want to ${approved ? 'approve' : 'reject'} this excuse?'),
              SizedBox(height: 10),

              Text('Excuse:', style: TextStyle(fontWeight: FontWeight.bold)),
              Text(excuseText), 
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
                updateExcuseStatus(docId, approved);
                Navigator.of(context).pop();
            },
            child: Text('Confirm'),
          ),
        ],
      );
    },
  );
}

  void updateExcuseStatus(String docId, bool approved) async {
    await _firestore.collection('excuses').doc(docId).update({'approved': approved});
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Excuse has been ${approved ? 'approved' : 'rejected'}'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Excuses for ${widget.courseCode}'),
        backgroundColor: Colors.deepPurple,
      ),
      body: FutureBuilder<List<Excuse>>(
        future: excusesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error fetching excuses'));
          } else if (snapshot.data!.isEmpty) {
            return Center(child: Text('No excuses submitted for this course'));
          } else {
            return 
          ListView.builder(
  itemCount: snapshot.data!.length,
  itemBuilder: (context, index) {
    Excuse excuse = snapshot.data![index];
    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        title: Text(excuse.userName),
        subtitle: Text(excuse.excuse),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            IconButton(
              icon: Icon(Icons.check, color: Colors.green),
              onPressed: () => confirmAction(excuse.docId, true, excuse.excuse),
            ),
            IconButton(
              icon: Icon(Icons.close, color: Colors.red),
              onPressed: () => confirmAction(excuse.docId, false, excuse.excuse),
            ),
          ],
        ),
      ),
    );
  },
);

          }
        },
      ),
    );
  }
}

class Excuse {
  final String userId;
  final String userName;
  final String courseCode;
  final String excuse;
  final String date;
  final String docId;

  Excuse({required this.userId, required this.userName, required this.courseCode, required this.excuse, required this.date, required this.docId});

  factory Excuse.fromFirestore(DocumentSnapshot doc, String userName) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Excuse(
      userId: data['userId'],
      userName: userName,
      courseCode: data['courseCode'],
      excuse: data['excuse'],
      date: (data['date'] as Timestamp).toDate().toString(),
      docId: doc.id,
    );
  }
}
