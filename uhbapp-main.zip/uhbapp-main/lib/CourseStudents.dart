import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CourseStudentsPage extends StatefulWidget {
  final String courseCode;

  CourseStudentsPage({Key? key, required this.courseCode}) : super(key: key);

  @override
  _CourseStudentsPageState createState() => _CourseStudentsPageState();
}

class _CourseStudentsPageState extends State<CourseStudentsPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<Student>> fetchStudentsForCourse() async {
    List<Student> students = [];
    var studentCourses = await _firestore
        .collection('student_courses')
        .where('courseCode', isEqualTo: widget.courseCode)
        .get();

    for (var studentCourse in studentCourses.docs) {
      var studentData = await _firestore
          .collection('users')
          .doc(studentCourse.data()['userId'] as String)
          .get();

      if (studentData.exists) {
        students.add(Student.fromDocument(studentData, studentCourse));
      }
    }
    return students;
  }

  Future<void> updateGrade(String studentCourseId, double grade) async {
    await _firestore.collection('student_courses').doc(studentCourseId).update({'grade': grade});
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Grade updated successfully')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Students in ${widget.courseCode}'),
        backgroundColor: Colors.deepPurple,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () {
              setState(() {

              });
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Student>>(
        future: fetchStudentsForCourse(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error fetching students'));
          } else if (snapshot.data!.isEmpty) {
            return Center(child: Text('No students found for this course'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                Student student = snapshot.data![index];
                TextEditingController gradeController = TextEditingController(text: student.grade.toString());
                return Card(
                  margin: EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(student.name),
                    subtitle: Text(student.email),
                    trailing: Container(
                      width: 100,
                      child: Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: gradeController,
                              keyboardType: TextInputType.number,
                              onSubmitted: (value) {
                                double? grade = double.tryParse(value);
                                if (grade != null) {
                                  updateGrade(student.studentCourseId, grade);
                                }
                              },
                            ),
                          ),
                          IconButton(
                            icon: Icon(Icons.save),
                            onPressed: () {
                              double? grade = double.tryParse(gradeController.text);
                              if (grade != null) {
                                updateGrade(student.studentCourseId, grade);
                              }
                            },
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}

class Student {
  final String name;
  final String email;
  final double grade;
  final String studentCourseId;

  Student({required this.name, required this.email, required this.grade, required this.studentCourseId});

  factory Student.fromDocument(DocumentSnapshot userDoc, DocumentSnapshot courseDoc) {
    Map<String, dynamic> userData = userDoc.data() as Map<String, dynamic>;
    Map<String, dynamic> courseData = courseDoc.data() as Map<String, dynamic>;
    return Student(
      name: userData['firstName'] + ' '+  userData['lastName']  ,
      email: userData['email'] ?? 'No Email',
      grade: (courseData['grade'] as num?)?.toDouble() ?? 0.0,
      studentCourseId: courseDoc.id,
    );
  }
}
