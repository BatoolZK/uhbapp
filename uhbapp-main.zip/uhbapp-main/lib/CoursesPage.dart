  import 'package:flutter/material.dart';

final Map<String, dynamic> courses = {
    'Current': [
      {'name': 'Algorithms and Data Structures', 'info': 'CS201 - Online'},
      {'name': 'Introduction to Machine Learning', 'info': 'CS301 - Hybrid'},
    ],
    'Past': [
      {'name': 'Fundamentals of Programming', 'info': 'CS101 - In Person'},
      {'name': 'Discrete Mathematics', 'info': 'MATH204 - Online'},
    ],
    'Future': [
      {'name': 'Operating Systems', 'info': 'CS401 - TBA'},
      {'name': 'Computer Networks', 'info': 'CS402 - Planned'},
    ],
  };
 
 
class CoursesPage extends StatefulWidget {
  @override
  _CoursesPageState createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
 
  void navigateToCourseDetails(String courseName, String courseInfo) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CourseDetailsPage(courseName: courseName, courseInfo: courseInfo),
      ),
    );
  }

  Widget buildCourseList(String category) {
    return ExpansionTile(
      title: Text(category),
      children: courses[category]!.map<Widget>((course) {
        return ListTile(
          title: Text(course['name']),
          subtitle: Text(course['info']),
          trailing: Icon(Icons.chevron_right),
          onTap: () => navigateToCourseDetails(course['name'], course['info']),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Courses'),
      ),
      body: ListView(
        children: <Widget>[
          buildCourseList('Current'),

        ],
      ),
    );
  }
}

class CourseDetailsPage extends StatelessWidget {
  final String courseName;
  final String courseInfo;

  CourseDetailsPage({required this.courseName, required this.courseInfo});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(courseName),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(courseInfo, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            Text('Materials', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),

          ],
        ),
      ),
    );
  }
}
