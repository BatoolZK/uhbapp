import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class DiscountsDetailPage extends StatelessWidget {
  final DateFormat dateFormatter = DateFormat('yyyy-MM-dd');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Available Discounts'),
        backgroundColor: Colors.orange,
      ),
      body: Container(
        color: Colors.orange.shade50,
        child: StreamBuilder(
          stream: FirebaseFirestore.instance.collection('discounts')
                    .orderBy('validUntil', descending: true)
                    .snapshots(),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasError) {
              return Text('Something went wrong: ${snapshot.error}');
            }

            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }

            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                var discount = snapshot.data!.docs[index];
                return DiscountCard(discount: discount, dateFormatter: dateFormatter);
              },
            );
          },
        ),
      ),
    );
  }
}

class DiscountCard extends StatelessWidget {
  final QueryDocumentSnapshot discount;
  final DateFormat dateFormatter;

  DiscountCard({required this.discount, required this.dateFormatter});

  @override
  Widget build(BuildContext context) {
    dynamic validUntil = discount['validUntil'];
    String formattedValidUntil;

    if (validUntil is Timestamp) {
      formattedValidUntil = dateFormatter.format(validUntil.toDate());
    } else if (validUntil is String) {
      formattedValidUntil = validUntil;
    } else {
      formattedValidUntil = 'Unknown';
    }

    return Card(
      elevation: 5,
      margin: EdgeInsets.all(10),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DiscountDetailPage(discount: discount, dateFormatter: dateFormatter),
            ),
          );
        },
        child: Column(
          children: [
            discount['imageUrl'] != null
              ? Image.network(
                  discount['imageUrl'],
                  width: double.infinity,
                  height: 200,
                  fit: BoxFit.cover,
                )
              : Container(height: 200, color: Colors.grey.shade300, alignment: Alignment.center, child: Text('No Image Available')),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    discount['title'],
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange.shade700,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    discount['description'],
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Validity: until $formattedValidUntil',
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DiscountDetailPage extends StatelessWidget {
  final QueryDocumentSnapshot discount;
  final DateFormat dateFormatter;

  DiscountDetailPage({required this.discount, required this.dateFormatter});

  @override
  Widget build(BuildContext context) {
    dynamic validFrom = discount['validFrom'];
    dynamic validUntil = discount['validUntil'];

    DateTime? fromDate = validFrom is String ? DateTime.tryParse(validFrom) : validFrom.toDate();
    DateTime? untilDate = validUntil is String ? DateTime.tryParse(validUntil) : validUntil.toDate();

    String formattedValidFrom = fromDate != null ? dateFormatter.format(fromDate) : 'Unknown';
    String formattedValidUntil = untilDate != null ? dateFormatter.format(untilDate) : 'Unknown';

    return Scaffold(
      appBar: AppBar(
        title: Text('Discount Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              discount['title'],
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.orange.shade700,
              ),
            ),
            SizedBox(height: 8),
            discount['imageUrl'] != null
              ? Image.network(
                  discount['imageUrl'],
                  width: double.infinity,
                  height: 200,
                  fit: BoxFit.cover,
                )
              : Container(height: 200, color: Colors.grey.shade300, alignment: Alignment.center, child: Text('No Image Available')),
            SizedBox(height: 16),
            Text(
              'Description:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              discount['description'],
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            Text(
              'Percent: ${discount['percent']}%',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            Text(
              'Validity:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'From: $formattedValidFrom',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Until: $formattedValidUntil',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            Text(
              'Conditions:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              discount['conditions'] ?? 'No conditions specified',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}

 