import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class EnrollPage extends StatefulWidget {
  @override
  _EnrollPageState createState() => _EnrollPageState();
}

class _EnrollPageState extends State<EnrollPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<int> levels = List.generate(8, (index) => index + 1); // Levels 1 to 8
  Map<int, bool> levelAccess = {1: true};
  Map<int, bool> levelEnrolled = {};
  Map<int, List<Map<String, dynamic>>> coursesByLevel = {};

  @override
  void initState() {
    super.initState();
    fetchLevelData();
    fetchAllCourses();
  }

  void fetchLevelData() async {
    User? user = _auth.currentUser;
    if (user != null) {
      var enrolledCourses = await _firestore.collection('student_courses')
          .where('userId', isEqualTo: user.uid)
          .get();

      Map<int, bool> tempLevelAccess = {1: true};
      Set<int> tempLevelEnrolled = Set();

      for (var doc in enrolledCourses.docs) {
        int level = doc.data()['level'] as int;
        dynamic grade = doc.data()['grade'];
        if (grade != null) {
          tempLevelAccess[level] = true;
          if (level < levels.length) {
            tempLevelAccess[level + 1] = true;
          }
        }
        tempLevelEnrolled.add(level);
      }

      setState(() {
        levelAccess = tempLevelAccess;
        levelEnrolled = tempLevelEnrolled.fold({}, (map, level) => map..[level] = true);
      });
    }
  }

  void fetchAllCourses() async {
    var allCourses = await _firestore.collection('courses').get();
    Map<int, List<Map<String, dynamic>>> tempCoursesByLevel = {};
    for (var doc in allCourses.docs) {
      int level = doc.data()['level'] as int;
      tempCoursesByLevel[level] = tempCoursesByLevel[level] ?? [];
      tempCoursesByLevel[level]?.add({
        'code': doc.data()['code'],
        'name': doc.data()['name'],
        'level': level
      });
    }

    setState(() {
      coursesByLevel = tempCoursesByLevel;
    });
  }

  Future<void> enrollInLevel(int level) async {
    User? user = _auth.currentUser;
    if (user != null && levelAccess[level] == true && !levelEnrolled.containsKey(level)) {
      var batch = _firestore.batch();
      var courses = coursesByLevel[level] ?? [];
      for (var course in courses) {
        var courseDoc = _firestore.collection('student_courses').doc();
        batch.set(courseDoc, {
          'userId': user.uid,
          'courseCode': course['code'],
          'courseName': course['name'],
          'level': level,
          'grade': null
        });
      }
      await batch.commit();
      await removeDuplicateCourses(user.uid);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Enrolled in Level $level courses')));
      setState(() {
        levelEnrolled[level] = true;
      });
    }
  }

  Future<void> removeDuplicateCourses(String userId) async {
    var studentCourses = await _firestore.collection('student_courses')
        .where('userId', isEqualTo: userId)
        .get();

    Map<String, DocumentSnapshot> uniqueCourses = {};
    List<DocumentSnapshot> duplicateCourses = [];

    for (var doc in studentCourses.docs) {
      String courseCode = doc.data()['courseCode'];
      if (uniqueCourses.containsKey(courseCode)) {
        duplicateCourses.add(doc);
      } else {
        uniqueCourses[courseCode] = doc;
      }
    }

    for (var doc in duplicateCourses) {
      await _firestore.collection('student_courses').doc(doc.id).delete();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Enroll in Level'),
      ),
      body: ListView.builder(
        itemCount: levels.length,
        itemBuilder: (context, index) {
          int level = levels[index];
          bool isAccessible = levelAccess[level] ?? false;
          bool isAlreadyEnrolled = levelEnrolled[level] ?? false;
          return ExpansionTile(
            title: Text('Level $level'),
            subtitle: Text(isAccessible ? (isAlreadyEnrolled ? 'Already enrolled' : 'Tap to enroll') : 'Locked'),
            trailing: ElevatedButton(
              onPressed: isAccessible && !isAlreadyEnrolled ? () => enrollInLevel(level) : null,
              child: Text('Enroll'),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(isAccessible && !isAlreadyEnrolled ? Colors.blue : Colors.grey),
              ),
            ),
            children: [
              Container(
                height: 120,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: coursesByLevel[level]?.length ?? 0,
                  itemBuilder: (context, courseIndex) {
                    var course = coursesByLevel[level]?[courseIndex];
                    return Card(
                      child: Container(
                        width: 160,
                        padding: EdgeInsets.all(8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(course?['name'] ?? '', style: TextStyle(fontWeight: FontWeight.bold)),
                            Text(course?['code'] ?? ''),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              )
            ],
            initiallyExpanded: index == 0,
          );
        },
      ),
    );
  }
}
