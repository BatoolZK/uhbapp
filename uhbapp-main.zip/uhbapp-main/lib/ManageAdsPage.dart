import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ManageAdsPage extends StatefulWidget {
  @override
  _ManageAdsPageState createState() => _ManageAdsPageState();
}

class _ManageAdsPageState extends State<ManageAdsPage> {
  final TextEditingController _adTitleController = TextEditingController();
  final TextEditingController _adContentController = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  XFile? _imageFile;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Ads'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () => _showAddAdDialog(context),
          ),
        ],
      ),
      body: StreamBuilder(
        stream: _db.collection('ads').snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                var ad = snapshot.data!.docs[index];
                return ListTile(
                  title: Text(ad['title']),
                  subtitle: Text(ad['content']),
                  leading: ad['imageUrl'] != null ? Image.network(ad['imageUrl'], width: 100, fit: BoxFit.cover) : SizedBox(width: 100),
                  trailing: Wrap(
                    spacing: 12,
                    children: <Widget>[
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () => _showEditAdDialog(context, ad),
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () => _deleteAd(ad.id),
                      ),
                    ],
                  ),
                );
              },
            );
          } else if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          }
          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  void _showAddAdDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add New Ad'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextField(
                  controller: _adTitleController,
                  decoration: InputDecoration(labelText: 'Title'),
                ),
                TextField(
                  controller: _adContentController,
                  decoration: InputDecoration(labelText: 'Content'),
                ),
                SizedBox(height: 20),
                OutlinedButton.icon(
                  icon: Icon(Icons.image),
                  label: Text('Add Image'),
                  onPressed: () => _pickImage(),
                ),
                SizedBox(height: 20),
                _imageFile == null ? Container() : Image.file(File(_imageFile!.path), height: 100),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _clearControllers();
              },
            ),
            TextButton(
              child: Text('Add'),
              onPressed: () {
                if (_validateFields()) {
                  _addAd();
                } else {
                  ScaffoldMessenger.of(context)
                    .showSnackBar(SnackBar(content: Text('Please fill all fields and add an image.')));
                }
              },
            ),
          ],
        );
      },
    );
  }

  bool _validateFields() {
    return _adTitleController.text.isNotEmpty && _adContentController.text.isNotEmpty && _imageFile != null;
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _imageFile = pickedFile;
    });
  }

  Future<void> _addAd() async {
    String? imageUrl = await _uploadImage(File(_imageFile!.path));
    _db.collection('ads').add({
      'title': _adTitleController.text,
      'content': _adContentController.text,
      'imageUrl': imageUrl,
      'date':DateTime.timestamp()
    });
    Navigator.of(context).pop();
    _clearControllers();
  }

  Future<String?> _uploadImage(File image) async {
    try {
      String fileName = 'ads/${DateTime.now().millisecondsSinceEpoch}_${image.path.split('/').last}';
      final ref = FirebaseStorage.instance.ref().child(fileName);
      await ref.putFile(image);
      return await ref.getDownloadURL();
    } catch (e) {
      print('Error uploading image: $e');
      return null;
    }
  }

  void _showEditAdDialog(BuildContext context, QueryDocumentSnapshot ad) {
    _adTitleController.text = ad['title'];
    _adContentController.text = ad['content'];
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Ad'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextField(
                  controller: _adTitleController,
                  decoration: InputDecoration(labelText: 'Title'),
                ),
                TextField(
                  controller: _adContentController,
                  decoration: InputDecoration(labelText: 'Content'),
                ),
                SizedBox(height: 20),
                OutlinedButton.icon(
                  icon: Icon(Icons.image),
                  label: Text('Change Image'),
                  onPressed: () => _pickImage(),
                ),
                SizedBox(height: 20),
                _imageFile == null ? (ad['imageUrl'] != null ? Image.network(ad['imageUrl'], height: 100) : Container()) : Image.file(File(_imageFile!.path), height: 100),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _clearControllers();
              },
            ),
            TextButton(
              child: Text('Update'),
              onPressed: () {
                if (_validateFields()) {
                  _updateAd(ad.id, ad['imageUrl']);
                } else {
                  ScaffoldMessenger.of(context)
                    .showSnackBar(SnackBar(content: Text('Please fill all fields and add an image.')));
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _updateAd(String adId, String? oldImageUrl) async {
    String? imageUrl = oldImageUrl;
    if (_imageFile != null) {
      if (oldImageUrl != null) {
        await FirebaseStorage.instance.refFromURL(oldImageUrl).delete();
      }
      imageUrl = await _uploadImage(File(_imageFile!.path));
    }

    _db.collection('ads').doc(adId).update({
      'title': _adTitleController.text,
      'content': _adContentController.text,
      'imageUrl': imageUrl,
    });
    Navigator.of(context).pop();
    _clearControllers();
  }

  void _deleteAd(String adId) {
    _db.collection('ads').doc(adId).delete();
  }

  void _clearControllers() {
    _adTitleController.clear();
    _adContentController.clear();
    _imageFile = null;
  }

  @override
  void dispose() {
    _adTitleController.dispose();
    _adContentController.dispose();
    super.dispose();
  }
}
