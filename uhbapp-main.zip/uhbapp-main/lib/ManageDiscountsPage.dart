import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ManageDiscountsPage extends StatefulWidget {
  @override
  _ManageDiscountsPageState createState() => _ManageDiscountsPageState();
}

class _ManageDiscountsPageState extends State<ManageDiscountsPage> {
  final TextEditingController _discountTitleController = TextEditingController();
  final TextEditingController _discountDescriptionController = TextEditingController();
  final TextEditingController _discountPercentController = TextEditingController();
  final TextEditingController _discountConditionsController = TextEditingController();
  DateTime? _validFrom;
  DateTime? _validUntil;
  final ImagePicker _picker = ImagePicker();
  XFile? _imageFile;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final DateFormat _dateFormatter = DateFormat('yyyy-MM-dd');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Discounts'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () => _showAddDiscountDialog(context),
          ),
        ],
      ),
      body: StreamBuilder(
        stream: _db.collection('discounts').snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                var discount = snapshot.data!.docs[index];
                return ListTile(
                  title: Text(discount['title']),
                  subtitle: Text("${discount['description']} - ${discount['percent']}% off, valid from ${discount['validFrom']} to ${discount['validUntil']}. Conditions: ${discount['conditions']}"),
                  leading: discount['imageUrl'] != null ? Image.network(discount['imageUrl'], width: 100, fit: BoxFit.cover) : null,
                  trailing: Wrap(
                    spacing: 12,
                    children: <Widget>[
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () => _showEditDiscountDialog(context, discount),
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () => _deleteDiscount(discount.id),
                      ),
                    ],
                  ),
                );
              },
            );
          } else if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          }
          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  void _showAddDiscountDialog(BuildContext context) {
    _resetImage();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add New Discount'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _discountTitleController,
                  decoration: InputDecoration(labelText: 'Title'),
                ),
                TextField(
                  controller: _discountDescriptionController,
                  decoration: InputDecoration(labelText: 'Description'),
                ),
                TextField(
                  controller: _discountPercentController,
                  decoration: InputDecoration(labelText: 'Discount Percent'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: _discountConditionsController,
                  decoration: InputDecoration(labelText: 'Conditions'),
                ),
                ListTile(
                  title: Text('Valid From: ${_validFrom != null ? _dateFormatter.format(_validFrom!) : 'Not set'}'),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () => _pickDate(context, isStart: true),
                ),
                ListTile(
                  title: Text('Valid Until: ${_validUntil != null ? _dateFormatter.format(_validUntil!) : 'Not set'}'),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () => _pickDate(context, isStart: false),
                ),
                _imageSection(),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _clearControllers();
              },
            ),
            TextButton(
              child: Text('Add'),
              onPressed: () {
                if (_validateFields()) {
                  _addDiscount();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please ensure all fields are filled correctly and the dates are valid.')));
                }
              },
            ),
          ],
        );
      },
    );
  }

  bool _validateFields() {
    return _discountTitleController.text.isNotEmpty &&
           _discountDescriptionController.text.isNotEmpty &&
           _discountPercentController.text.isNotEmpty &&
           _validFrom != null &&
           _validUntil != null &&
           _validFrom!.isBefore(_validUntil!) &&
           _imageFile != null;
  }

  void _addDiscount() async {
    String? imageUrl = await _uploadImage(File(_imageFile!.path));
    _db.collection('discounts').add({
      'title': _discountTitleController.text,
      'description': _discountDescriptionController.text,
      'percent': int.tryParse(_discountPercentController.text) ?? 0,
      'conditions': _discountConditionsController.text,
      'validFrom': _dateFormatter.format(_validFrom!),
      'validUntil': _dateFormatter.format(_validUntil!),
      'imageUrl': imageUrl,
    });
    Navigator.of(context).pop();
    _clearControllers();
  }

  Future<void> _pickDate(BuildContext context, {required bool isStart}) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: (isStart ? _validFrom : _validUntil) ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          _validFrom = picked;
        } else {
          _validUntil = picked;
        }
      });
    }
  }

  Widget _imageSection() {
    return Column(
      children: [
        OutlinedButton.icon(
          icon: Icon(Icons.image),
          label: Text('Add Image'),
          onPressed: () => _pickImage(),
        ),
        SizedBox(height: 8),
        _imageFile == null ? Container() : Image.file(File(_imageFile!.path), height: 100),
      ],
    );
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _imageFile = pickedFile;
    });
  }

  Future<String?> _uploadImage(File image) async {
    try {
      String fileName = 'discounts/${DateTime.now().millisecondsSinceEpoch}_${image.path.split('/').last}';
      final ref = FirebaseStorage.instance.ref().child(fileName);
      await ref.putFile(image);
      return await ref.getDownloadURL();
    } catch (e) {
      print('Error uploading image: $e');
      return null;
    }
  }

  void _showEditDiscountDialog(BuildContext context, QueryDocumentSnapshot discount) {
    _discountTitleController.text = discount['title'];
    _discountDescriptionController.text = discount['description'];
    _discountPercentController.text = discount['percent'].toString();
    _discountConditionsController.text = discount['conditions'];
    _validFrom = _dateFormatter.parse(discount['validFrom']);
    _validUntil = _dateFormatter.parse(discount['validUntil']);
    _resetImage();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Discount'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _discountTitleController,
                  decoration: InputDecoration(labelText: 'Title'),
                ),
                TextField(
                  controller: _discountDescriptionController,
                  decoration: InputDecoration(labelText: 'Description'),
                ),
                TextField(
                  controller: _discountPercentController,
                  decoration: InputDecoration(labelText: 'Discount Percent'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: _discountConditionsController,
                  decoration: InputDecoration(labelText: 'Conditions'),
                ),
                ListTile(
                  title: Text('Valid From: ${_dateFormatter.format(_validFrom!)}'),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () => _pickDate(context, isStart: true),
                ),
                ListTile(
                  title: Text('Valid Until: ${_dateFormatter.format(_validUntil!)}'),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () => _pickDate(context, isStart: false),
                ),
                _imageSection(),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _clearControllers();
              },
            ),
            TextButton(
              child: Text('Update'),
              onPressed: () async {
                if (_validateFields()) {
                  String? imageUrl = discount['imageUrl'];
                  if (_imageFile != null) {
                    if (imageUrl != null) {

                      await FirebaseStorage.instance.refFromURL(imageUrl).delete();
                    }
                    imageUrl = await _uploadImage(File(_imageFile!.path));
                  }
                  _updateDiscount(discount.id, imageUrl);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please ensure all fields are filled correctly and the dates are valid.')));
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _updateDiscount(String discountId, String? imageUrl) {
    _db.collection('discounts').doc(discountId).update({
      'title': _discountTitleController.text,
      'description': _discountDescriptionController.text,
      'percent': int.tryParse(_discountPercentController.text) ?? 0,
      'conditions': _discountConditionsController.text,
      'validFrom': _dateFormatter.format(_validFrom!),
      'validUntil': _dateFormatter.format(_validUntil!),
      'imageUrl': imageUrl,
    });
    Navigator.of(context).pop();
    _clearControllers();
  }

  void _deleteDiscount(String discountId) {
    _db.collection('discounts').doc(discountId).delete();
  }

  void _clearControllers() {
    _discountTitleController.clear();
    _discountDescriptionController.clear();
    _discountPercentController.clear();
    _discountConditionsController.clear();
    _validFrom = null;
    _validUntil = null;
    _resetImage();
  }

  void _resetImage() {
    setState(() {
      _imageFile = null;
    });
  }

  @override
  void dispose() {
    _discountTitleController.dispose();
    _discountDescriptionController.dispose();
    _discountPercentController.dispose();
    _discountConditionsController.dispose();
    super.dispose();
  }
}
