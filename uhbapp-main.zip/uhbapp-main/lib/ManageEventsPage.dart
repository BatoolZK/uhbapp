import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'dart:io';

class ManageEventsPage extends StatefulWidget {
  @override
  _ManageEventsPageState createState() => _ManageEventsPageState();
}

class _ManageEventsPageState extends State<ManageEventsPage> {
  final TextEditingController _eventNameController = TextEditingController();
  final TextEditingController _eventDescriptionController = TextEditingController();
  final TextEditingController _eventLocationController = TextEditingController();
  DateTime? _eventStartDate;
  DateTime? _eventEndDate;
  XFile? _imageFile;
  final ImagePicker _picker = ImagePicker();
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final DateFormat _dateFormatter = DateFormat('yyyy-MM-dd');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Events'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () => _showAddEventDialog(context),
          ),
        ],
      ),
      body: StreamBuilder(
        stream: _db.collection('events').snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                var event = snapshot.data!.docs[index];
                return ListTile(
                  title: Text(event['name']),
                  subtitle: Text("${event['description']} at ${event['location']} from ${event['startDate']} to ${event['endDate']}"),
                  leading: event['imageUrl'] != null ? Image.network(event['imageUrl'], width: 100, height: 100, fit: BoxFit.cover) : null,
                  trailing: Wrap(
                    spacing: 12,
                    children: <Widget>[
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () => _showEditEventDialog(context, event),
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () => _deleteEvent(event.id),
                      ),
                    ],
                  ),
                );
              },
            );
          } else if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          }
          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  void _showAddEventDialog(BuildContext context) {
    _resetImage();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add New Event'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _eventNameController,
                  decoration: InputDecoration(labelText: 'Event Name'),
                ),
                TextField(
                  controller: _eventDescriptionController,
                  decoration: InputDecoration(labelText: 'Description'),
                ),
                TextField(
                  controller: _eventLocationController,
                  decoration: InputDecoration(labelText: 'Location'),
                ),
                ListTile(
                  title: Text('Start Date: ${_eventStartDate != null ? _dateFormatter.format(_eventStartDate!) : 'Not set'}'),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () => _pickDate(context, isStartDate: true),
                ),
                ListTile(
                  title: Text('End Date: ${_eventEndDate != null ? _dateFormatter.format(_eventEndDate!) : 'Not set'}'),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () => _pickDate(context, isStartDate: false),
                ),
                _imageSection(),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _clearControllers();
              },
            ),
            TextButton(
              child: Text('Add'),
              onPressed: () {
                if (_validateFields()) {
                  _addEvent();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please ensure all fields are filled correctly and dates are valid.')));
                }
              },
            ),
          ],
        );
      },
    );
  }

  Widget _imageSection() {
    return Column(
      children: [
        OutlinedButton.icon(
          icon: Icon(Icons.image),
          label: Text('Add Image'),
          onPressed: () => _pickImage(),
        ),
        SizedBox(height: 8),
        _imageFile == null ? Container() : Image.file(File(_imageFile!.path), height: 100),
      ],
    );
  }

  Future<void> _pickDate(BuildContext context, {required bool isStartDate}) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: (isStartDate ? _eventStartDate : _eventEndDate) ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isStartDate) {
          _eventStartDate = picked;
        } else {
          _eventEndDate = picked;
        }
      });
    }
  }

  bool _validateFields() {
    return _eventNameController.text.isNotEmpty &&
        _eventDescriptionController.text.isNotEmpty &&
        _eventLocationController.text.isNotEmpty &&
        _eventStartDate != null &&
        _eventEndDate != null &&
        _eventStartDate!.isBefore(_eventEndDate!) &&
        _imageFile != null;
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _imageFile = pickedFile;
    });
  }

  Future<String?> _uploadImage(File image) async {
    try {
      String fileName = 'events/${DateTime.now().millisecondsSinceEpoch}_${image.path.split('/').last}';
      final ref = FirebaseStorage.instance.ref().child(fileName);
      await ref.putFile(image);
      return await ref.getDownloadURL();
    } catch (e) {
      print('Error uploading image: $e');
      return null;
    }
  }

  void _addEvent() async {
    String? imageUrl = await _uploadImage(File(_imageFile!.path));
    _db.collection('events').add({
      'name': _eventNameController.text,
      'description': _eventDescriptionController.text,
      'location': _eventLocationController.text,
      'startDate': _dateFormatter.format(_eventStartDate!),
      'endDate': _dateFormatter.format(_eventEndDate!),
      'imageUrl': imageUrl,
    });
    Navigator.of(context).pop();
    _clearControllers();
  }

  void _showEditEventDialog(BuildContext context, QueryDocumentSnapshot event) {
    _eventNameController.text = event['name'];
    _eventDescriptionController.text = event['description'];
    _eventLocationController.text = event['location'];
    _eventStartDate = _dateFormatter.parse(event['startDate']);
    _eventEndDate = _dateFormatter.parse(event['endDate']);
    _imageFile = null;  

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Event'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _eventNameController,
                  decoration: InputDecoration(labelText: 'Event Name'),
                ),
                TextField(
                  controller: _eventDescriptionController,
                  decoration: InputDecoration(labelText: 'Description'),
                ),
                TextField(
                  controller: _eventLocationController,
                  decoration: InputDecoration(labelText: 'Location'),
                ),
                ListTile(
                  title: Text('Start Date: ${_dateFormatter.format(_eventStartDate!)}'),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () => _pickDate(context, isStartDate: true),
                ),
                ListTile(
                  title: Text('End Date: ${_dateFormatter.format(_eventEndDate!)}'),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () => _pickDate(context, isStartDate: false),
                ),
                _imageSection(),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _clearControllers();
              },
            ),
            TextButton(
              child: Text('Update'),
              onPressed: () async {
                if (_validateFields()) {
                  String? imageUrl = event['imageUrl'];
                  if (_imageFile != null) {
                    if (imageUrl != null) {

                      await FirebaseStorage.instance.refFromURL(imageUrl).delete();
                    }
                    imageUrl = await _uploadImage(File(_imageFile!.path));
                  }
                  _updateEvent(event.id, imageUrl);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please ensure all fields are filled correctly and dates are valid.')));
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _updateEvent(String eventId, String? imageUrl) {
    _db.collection('events').doc(eventId).update({
      'name': _eventNameController.text,
      'description': _eventDescriptionController.text,
      'location': _eventLocationController.text,
      'startDate': _dateFormatter.format(_eventStartDate!),
      'endDate': _dateFormatter.format(_eventEndDate!),
      'imageUrl': imageUrl,
    });
    Navigator.of(context).pop();
    _clearControllers();
  }

  void _deleteEvent(String eventId) {
    _db.collection('events').doc(eventId).delete();
  }

  void _clearControllers() {
    _eventNameController.clear();
    _eventDescriptionController.clear();
    _eventLocationController.clear();
    _eventStartDate = null;
    _eventEndDate = null;
    _resetImage();
  }

  void _resetImage() {
    setState(() {
      _imageFile = null;
    });
  }

  @override
  void dispose() {
    _eventNameController.dispose();
    _eventDescriptionController.dispose();
    _eventLocationController.dispose();
    super.dispose();
  }
}
