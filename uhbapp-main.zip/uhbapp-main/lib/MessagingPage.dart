import 'package:flutter/material.dart';

class MessagingPage extends StatefulWidget {
  @override
  _MessagingPageState createState() => _MessagingPageState();
}

class _MessagingPageState extends State<MessagingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Messages'),
      ),
      body: ListView.builder(
        itemCount: 10,  
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(
               child: Icon(Icons.person),
            ),
            title: Text('User $index'),
            subtitle: Text('Last message snippet...'),
            onTap: () {
             },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.message),
        onPressed: () {
         },
      ),
    );
  }
}
