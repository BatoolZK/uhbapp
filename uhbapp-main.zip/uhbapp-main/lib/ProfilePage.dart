import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uhbapp/login.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? user;
  String username = "";
  String email = "";
  String studentID = "";
  String userType = "";
  XFile? _image;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    user = _auth.currentUser;
    _loadUserProfile();
  }

  Future<void> _loadUserProfile() async {
    if (user != null) {
      var userDocument = _firestore.collection('users').doc(user!.uid);
      userDocument.get().then((doc) {
        if (doc.exists) {
          setState(() {
            username = doc.data()!['firstName'];
            email = doc.data()!['email'];
            studentID = doc.data()!['studentID'] ?? "";
            userType = doc.data()!['type'];
          });
        }
      }).catchError((e) {
        print("Error fetching user data: $e");
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          _buildProfileImage(),
          SizedBox(height: 20),
          _buildUserInfo('Username', username, () => _editUsername()),
          _buildUserInfo('Email', email, () => _editEmail()),
          if (userType == 'student') _buildUserInfo('Student ID', studentID, () => _editStudentID()),
        ],
      ),
    );
  }

  Widget _buildProfileImage() {
    return Center(
      child: GestureDetector(
        onTap: () => _pickImage(),
        child: CircleAvatar(
          radius: 60,
          backgroundImage: _image != null ? FileImage(File(_image!.path)) : null,
          child: _image == null ? Icon(Icons.camera_alt, size: 30) : null,
        ),
      ),
    );
  }

  Widget _buildUserInfo(String label, String value, VoidCallback onTap) {
    return ListTile(
      title: Text(label),
      subtitle: Text(value),
      trailing: Icon(Icons.edit),
      onTap: onTap,
    );
  }

  void _editUsername() {
    _editField("Edit Username", username, (value) {
      _firestore.collection('users').doc(user!.uid).update({'firstName': value}).then((_) {
        print("Name updated in Firestore");
      }).catchError((error) {
        print("Failed to update name: $error");
      });
      setState(() {
        username = value;
      });
    });
  }

  void _editEmail() {
    _editField("Edit Email", email, (value) {
      user!.updateEmail(value).then((_) {
        _firestore.collection('users').doc(user!.uid).update({'email': value}).then((_) {
          print("Email updated in Firestore");
        }).catchError((error) {
          print("Failed to update email in Firestore: $error");
        });
        print("Email updated in Firebase Auth");
      }).catchError((error) {
        print("Failed to update email in Firebase Auth: $error");
      });
      setState(() {
        email = value;
      });
    });
  }

  void _editStudentID() {
    _editField("Edit Student ID", studentID, (value) {
      _firestore.collection('users').doc(user!.uid).update({'studentID': value}).then((_) {
        print("Student ID updated in Firestore");
      }).catchError((error) {
        print("Failed to update Student ID: $error");
      });
      setState(() {
        studentID = value;
      });
    });
  }

  void _editField(String title, String currentValue, Function(String) onSave) {
    showDialog(
      context: context,
      builder: (context) {
        TextEditingController controller = TextEditingController(text: currentValue);
        return AlertDialog(
          title: Text(title),
          content: TextField(
            controller: controller,
            decoration: InputDecoration(labelText: title),
            onChanged: (value) {
              controller.text = value;
              controller.selection = TextSelection.fromPosition(TextPosition(offset: controller.text.length));
            },
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text('Save'),
              onPressed: () {
                onSave(controller.text);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _image = pickedFile;
    });
  }

  void _logout(BuildContext context) {
    _auth.signOut().then((_) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => LoginPage()));
    }).catchError((error) {
      print("Logout failed: $error");
    });
  }
}
