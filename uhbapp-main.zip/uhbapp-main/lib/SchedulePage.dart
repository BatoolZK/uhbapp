import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SchedulePage extends StatefulWidget {
  @override
  _SchedulePageState createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  User? user = FirebaseAuth.instance.currentUser;
  late Future<Map<String, List<Map<String, String>>>> scheduleFuture;

  @override
  void initState() {
    super.initState();
    if (user != null) {
      scheduleFuture = _fetchSchedule();
    }
  }

  Future<Map<String, List<Map<String, String>>>> _fetchSchedule() async {
    Map<String, List<Map<String, String>>> weeklySchedule = {
      'Sunday': [], 'Monday': [], 'Tuesday': [], 'Wednesday': [],
      'Thursday': [], 'Friday': [], 'Saturday': [],
    };
    Set<String> uniqueCourses = Set(); 


    QuerySnapshot studentCoursesSnapshot = await FirebaseFirestore.instance
        .collection('studentCourses')
        .where('studentId', isEqualTo: user!.uid)
        .get();

    for (var doc in studentCoursesSnapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      String courseName = data['course'] ?? 'Unknown Course';

      if (!uniqueCourses.contains(courseName)) {
        uniqueCourses.add(courseName);
        DocumentSnapshot teacherCourseDoc = await FirebaseFirestore.instance
            .collection('teacherCourses')
            .where('course', isEqualTo: courseName)
            .limit(1)
            .get()
            .then((snapshot) => snapshot.docs.first);

        Map<String, dynamic> teacherCourseData = teacherCourseDoc.data() as Map<String, dynamic>;
        String day = teacherCourseData['day'] ?? 'Day N/A';
        String startTime = teacherCourseData['startTime'] ?? 'Start Time N/A';
        String endTime = teacherCourseData['endTime'] ?? 'End Time N/A';
        String room = teacherCourseData['room'] ?? 'Room N/A';

        weeklySchedule[day]!.add({
          'name': courseName,
          'time': '$startTime - $endTime',
          'location': room,
        });
      }
    }

    return weeklySchedule;
  }

  @override
  Widget build(BuildContext context) {
    if (user == null) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Weekly Schedule'),
          centerTitle: true,
          elevation: 0,
        ),
        body: Center(
          child: Text("Please log in to see your schedule."),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Weekly Schedule'),
        centerTitle: true,
        elevation: 0,
      ),
      body: FutureBuilder<Map<String, List<Map<String, String>>>>(
        future: scheduleFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData) {
            return Center(child: Text("No courses found"));
          }

          var weeklySchedule = snapshot.data!;
          return ListView.builder(
            itemCount: weeklySchedule.length,
            itemBuilder: (context, index) {
              String day = weeklySchedule.keys.elementAt(index);
              var daySchedule = weeklySchedule[day]!;
              return daySchedule.isEmpty
                  ? Container()
                  : Card(
                      margin: EdgeInsets.all(8.0),
                      child: ExpansionTile(
                        backgroundColor: Colors.deepPurple.shade50,
                        title: Text(
                          day,
                          style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                        ),
                        children: daySchedule.map<Widget>((cls) {
                          return ListTile(
                            leading: Icon(Icons.class_, color: Colors.deepPurple),
                            title: Text(
                              cls['name']!,
                              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
                            ),
                            subtitle: Text(
                              '${cls['time']} at room ${cls['location']}',
                              style: TextStyle(fontSize: 16.0),
                            ),
                          );
                        }).toList(),
                      ),
                    );
            },
          );
        },
      ),
    );
  }
}
