import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uhbapp/CourseDetailsPage.dart';

class SchedulePage_S extends StatefulWidget {
  @override
  _SchedulePage_SState createState() => _SchedulePage_SState();
}

class _SchedulePage_SState extends State<SchedulePage_S> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<Course>> fetchStudentCourses() async {
    User? user = _auth.currentUser;
    List<Course> courses = [];

    if (user != null) {
      var snapshots = await _firestore
          .collection('student_courses')
          .where('userId', isEqualTo: user.uid)
          .get();

      for (var doc in snapshots.docs) {
        var courseData = doc.data();
        var courseDoc = await _firestore
            .collection('courses')
            .where('code', isEqualTo: courseData['courseCode'])
            .limit(1)
            .get();

        if (courseDoc.docs.isNotEmpty) {
          var course = Course.fromFirestore(courseDoc.docs.first);
          courses.add(course);
        }
      }
    }
    return courses;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Class Schedule'),
        backgroundColor: Colors.deepPurple,
      ),
      body: FutureBuilder<List<Course>>(
        future: fetchStudentCourses(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error fetching schedule'));
          } else if (snapshot.data!.isEmpty) {
            return Center(child: Text('No classes scheduled yet'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                var course = snapshot.data![index];
                return Card(
                  margin: EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(course.name),
                    subtitle: Text('Code: ${course.code}'),
                    trailing: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('Day: ${course.day}'),
                        Text('Time: ${course.hour}:00'),
                        Text('Duration: ${course.duration} hr(s)'),
                      ],
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CourseDetailsPage(courseCode: course.code),
                        ),
                      );
                    },
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}

class Course {
  final String code;
  final String name;
  final String day;
  final int hour;
  final int duration;

  Course({required this.code, required this.name, required this.day, required this.hour, required this.duration});

  factory Course.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Course(
      code: data['code'],
      name: data['name'],
      day: data['day'],
      hour: data['hour'],
      duration: data['duration'],
    );
  }
}
