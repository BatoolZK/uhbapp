import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:uhbapp/AdminStudentSearchPage.dart';
import 'package:uhbapp/AdminTeacherSearchPage.dart'; 
import 'package:uhbapp/AttendanceChartPage.dart';
import 'package:uhbapp/ManageAdsPage.dart';
import 'package:uhbapp/ManageDiscountsPage.dart';
import 'package:uhbapp/ManageEventsPage.dart'; 
import 'package:uhbapp/login.dart';
 
class ServiceItem {
  final String title;
  final IconData icon;
  final VoidCallback onTap;

  ServiceItem({required this.title, required this.icon, required this.onTap});
}

class ServicesAdminPage extends StatelessWidget {
  final List<ServiceItem> services = [
     ServiceItem(
      
     title: 'Manage c',
        icon: Icons.campaign,
      onTap: () => print('Manage Ads'),
    ),
    ServiceItem(
      title: 'Manage Discounts',
        icon: Icons.local_offer,
      onTap: () => print('Manage Discounts'),
    ),
    ServiceItem(
      title: 'Manage Events',
        icon: Icons.event,
      onTap: () => print('Manage Events'),
    ),
      ServiceItem(
      title: 'Manage Events',
        icon: Icons.event,
      onTap: () => print('Manage Events'),
    ),
    
       ServiceItem(
      title: 'Manage Events',
        icon: Icons.event,
      onTap: () => print('Manage Events'),
    ),
    
     
    
  ];

  @override
  Widget build(BuildContext context) {
      services[0] = ServiceItem(
    title: 'Manage Ads',
    icon: Icons.campaign, 

    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ManageAdsPage())),
  ); services[1] = ServiceItem(
    title: 'Manage Discounts',
    icon: Icons.local_offer,  
    
    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ManageDiscountsPage())),
  );
  services[2] = ServiceItem(
    title: 'Manage Events',
    icon: Icons.event,  
    
    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ManageEventsPage())),
  );

 services[3] = ServiceItem(
    title: 'Manage Teachers',
    icon: Icons.people_rounded,  
    
    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => AdminTeacherSearchPage())),
  );
 services[4] = ServiceItem(
    title: 'Manage Students',
    icon: Icons.spatial_audio_rounded,  
    
    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => AdminStudentSearchPage())),
  );


  

  
    return Scaffold(
      appBar: AppBar(
        title: Text('Hello, Admin!', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.purple,
         automaticallyImplyLeading: false, 
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Colors.white),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 20,
            mainAxisSpacing: 20,
            childAspectRatio: 1 / 1.2,
          ),
          itemCount: services.length,
          itemBuilder: (context, index) {
            return _buildServiceCard(context, services[index]);
          },
        ),
      ),
    );
  }

  Widget _buildServiceCard(BuildContext context, ServiceItem service) {
    return InkWell(
      onTap: service.onTap,
      child: Card(
        color: Colors.purple.shade100,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(service.icon, size: 48, color: Colors.purple.shade800),
            SizedBox(height: 10),
            Text(
              service.title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.purple.shade800,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

   void _logout(BuildContext context) {
    FirebaseAuth.instance.signOut().then((value) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => LoginPage()));
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Failed to log out"),
      ));
    });
  }
}
