import 'package:flutter/material.dart';
import 'package:uhbapp/AcademicRecordsPage.dart';
import 'package:uhbapp/AttendanceChartPage.dart';
import 'package:uhbapp/ChatOverviewPage.dart';
import 'package:uhbapp/ChatScreen.dart';
import 'package:uhbapp/EnrollPage.dart';
import 'package:uhbapp/SubmitExcusePage.dart';
import 'package:uhbapp/excuses.dart';
import 'package:uhbapp/map.dart';

class ServiceItem {
  final String title;
  final IconData icon;
  final VoidCallback onTap;

  ServiceItem({required this.title, required this.icon, required this.onTap});
}

class ServicesPage extends StatelessWidget {
  final List<ServiceItem> services = [
    ServiceItem(
      title: 'Enroll',
      icon: Icons.system_security_update_good_sharp,
      onTap: () => print(''),
    ), ServiceItem(
      title: 'Academic Records',
      icon: Icons.book_online,
      onTap: () => print('Academic Records'),
    ),
    ServiceItem(
      title: 'Campus Map',
      icon: Icons.map_outlined,
      onTap: () => print('Campus Map'),
    ),
    ServiceItem(
      title: 'Submit Excuse',
      icon: Icons.assignment_late,
      onTap: () => print('Submit Excuse'),
    ), 
    ServiceItem(
      title: 'Attendance Status',
      icon: Icons.assignment_late,
      onTap: () => print('Attendance Status'),
    ), ServiceItem(
      title: 'Attendance Status',
      icon: Icons.assignment_late,
      onTap: () => print('Attendance Status'),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    services[0] = ServiceItem(
      title: 'Enroll',
      icon: Icons.book_online,
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => EnrollPage()));
      },
    ); services[1] = ServiceItem(
      title: 'Academic Records',
      icon: Icons.book_online,
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => AcademicRecordsPage()));
      },
    );
    services[2] = ServiceItem(
      title: 'Campus Map',
      icon: Icons.map_outlined,
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => EmbeddedGoogleMapPage()));
      },
    );
    services[3] = ServiceItem(
      title: 'My Excuses',
      icon: Icons.assignment_late,
      onTap: () {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => ExcusesPage()));
      },
    );

    services[4] = ServiceItem(
      title: 'Attendance Status',
      icon: Icons.access_time,
      onTap: () => Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => AttendancePage())),
    );

  services[5] = ServiceItem(
      title: 'Chats',
      icon: Icons.chat,
      onTap: () => Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => ChatHomePage())),
    );

    return Scaffold(
      appBar: AppBar(
        title: Text('Services'),
        backgroundColor: const Color.fromARGB(255, 255, 255, 255),
      ),
      
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 20,
            mainAxisSpacing: 20,
            childAspectRatio: 1 / 1.2,
          ),
          itemCount: services.length,
          itemBuilder: (context, index) {
            return _buildServiceCard(context, services[index]);
          },
        ),
      ),
    );
  }

  Widget _buildServiceCard(BuildContext context, ServiceItem service) {
    return InkWell(
      onTap: service.onTap,
      child: Card(
        color: Colors.purple.shade100,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(service.icon, size: 48, color: Colors.purple.shade800),
            SizedBox(height: 10),
            Text(
              service.title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.purple.shade800,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
