import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class StudentDetailsPage extends StatelessWidget {
  final Map<String, dynamic> student;

  StudentDetailsPage({required this.student});

  Future<List<Map<String, dynamic>>> fetchStudentCourses() async {
    var coursesSnapshot = await FirebaseFirestore.instance
        .collection('student_courses')
        .where('userId', isEqualTo: student['id'])
        .get();

    List<Map<String, dynamic>> courses = [];
    for (var doc in coursesSnapshot.docs) {
      var data = doc.data();
      var courseDoc = await FirebaseFirestore.instance
          .collection('courses')
          .where('code', isEqualTo: data['courseCode'])
          .limit(1)
          .get();

      if (courseDoc.docs.isNotEmpty) {
        var courseData = courseDoc.docs.first.data();
        courseData['grade'] = data['grade'];
        courses.add(courseData);
      }
    }

    return courses;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student Details'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: fetchStudentCourses(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error fetching courses'));
          } else if (snapshot.data!.isEmpty) {
            return Center(child: Text('No courses found for this student'));
          } else {
            var courses = snapshot.data!;
            var lastLevel = courses.isEmpty ? 'N/A' : courses.last['level'].toString();
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Name: ${student['firstName']} ${student['lastName']}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 10),
                  Text('Email: ${student['email']}', style: TextStyle(fontSize: 16)),
                  SizedBox(height: 10),
                  Text('Student ID: ${student['studentID']}', style: TextStyle(fontSize: 16)),
                  SizedBox(height: 10),
                  Text('Last Level: $lastLevel', style: TextStyle(fontSize: 16)),
                  SizedBox(height: 20),
                  Text('Courses:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Expanded(
                    child: ListView.builder(
                      itemCount: courses.length,
                      itemBuilder: (context, index) {
                        var course = courses[index];
                        return Card(
                          margin: EdgeInsets.symmetric(vertical: 5),
                          child: ListTile(
                            title: Text(course['name']),
                            subtitle: Text('Code: ${course['code']}\nGrade: ${course['grade'] ?? 'N/A'}'),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
