import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SubmitExcusePage extends StatefulWidget {
  @override
  _SubmitExcusePageState createState() => _SubmitExcusePageState();
}

class _SubmitExcusePageState extends State<SubmitExcusePage> {
  final _formKey = GlobalKey<FormState>();
  String _name = '';
  String _courseCode = '';
  DateTime _date = DateTime.now(); 

  String _reason = '';


  void _submitForm() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await FirebaseFirestore.instance.collection('excuses').add({
          'name': _name,
          'courseCode': _courseCode,
          'date': _date.toString(),  

          'reason': _reason,
          'userId': user.uid,  

        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Excuse Submitted Successfully')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No user found. Please login.')),
        );
      }
    }
  }


  Future<void> _pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _date, 

      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (picked != null && picked != _date) {
      setState(() {
        _date = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Request for Lecture Excuse'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(
                  decoration: InputDecoration(labelText: 'Name'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your name';
                    }
                    return null;
                  },
                  onSaved: (value) => _name = value!,
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Course Code'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the course code';
                    }
                    return null;
                  },
                  onSaved: (value) => _courseCode = value!,
                ),
                ListTile(
                  title: Text('Date of Lecture: ${_date.year}-${_date.month}-${_date.day}'),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () => _pickDate(context), 

                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Reason for Absence'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the reason for your absence';
                    }
                    return null;
                  },
                  onSaved: (value) => _reason = value!,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: ElevatedButton(
                    onPressed: _submitForm,
                    child: Text('Submit Excuse'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
