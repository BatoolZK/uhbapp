import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TeacherAssignedCoursesPage extends StatefulWidget {
  final String teacherEmail;

  TeacherAssignedCoursesPage({required this.teacherEmail});

  @override
  _TeacherAssignedCoursesPageState createState() => _TeacherAssignedCoursesPageState();
}

class _TeacherAssignedCoursesPageState extends State<TeacherAssignedCoursesPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<Map<String, dynamic>> courses = [];
  bool _isLoading = true;
  String _error = '';

  @override
  void initState() {
    super.initState();
    fetchAssignedCourses();
  }

  Future<void> fetchAssignedCourses() async {
    try {
      var coursesSnapshot = await _firestore
          .collection('courses')
          .where('instructor', isEqualTo: widget.teacherEmail)
          .get();

      List<Map<String, dynamic>> tempCourses = [];
      for (var doc in coursesSnapshot.docs) {
        tempCourses.add(doc.data());
      }

      setState(() {
        courses = tempCourses;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Error fetching courses: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Assigned Courses'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _error.isNotEmpty
              ? Center(child: Text(_error))
              : courses.isEmpty
                  ? Center(child: Text('No courses assigned'))
                  : ListView.builder(
                      itemCount: courses.length,
                      itemBuilder: (context, index) {
                        var course = courses[index];
                        return Card(
                          child: ListTile(
                            title: Text(course['name']),
                            subtitle: Text(
                                'Code: ${course['code']}\nDay: ${course['day']}\nTime: ${course['hour']}:00\nDuration: ${course['duration']} hour(s)'),
                            isThreeLine: true,
                          ),
                        );
                      },
                    ),
    );
  }
}
