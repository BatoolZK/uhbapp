import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';  

class TeacherCourseAssignmentPage extends StatefulWidget {
  final String teacherId;
  final String teacherName;

  TeacherCourseAssignmentPage({Key? key, required this.teacherId, required this.teacherName}) : super(key: key);

  @override
  _TeacherCourseAssignmentPageState createState() => _TeacherCourseAssignmentPageState();
}

class _TeacherCourseAssignmentPageState extends State<TeacherCourseAssignmentPage> {
  final List<List<String>> courseNames = [
    ["MATH 101", "PHYS101", "ENGL101", "CHEM111", "IAS111", "PE101"],
    ["MATH102", "PHYS102", "ENGL102", "CSE102", "IAS101", "PE102"],
    ["EE200", "CSE201", "ENGL214", "MATH201", "IAS212"],
    ["SWE205", "SWE215", "CSE202", "BIOL233", "CSE253"],
    ["SWE326", "CSE333", "CSE324", "SWE316", "IAS201"],
    ["STAT319", "CSE343", "CSE353", "SWE312", "SWE387", "IAS301", "SWE399"],
    ["STAT319", "SWE417", "CSE335", "CSE309", "SWE363", "IAS322"],
    ["CSE401", "STAT319", "CSE309", "SWE418", "STAT319"],
  ];

  Map<String, String?> assignedCourseIds = {};
  String? selectedCourse;
  String? day;
  TimeOfDay? startTime;
  TimeOfDay? endTime;
  String? room;

  @override
  void initState() {
    super.initState();
    _fetchAssignedCourses();
  }

  Future<void> _fetchAssignedCourses() async {
    FirebaseFirestore.instance
      .collection('teacherCourses')
      .where('teacherId', isEqualTo: widget.teacherId)
      .get()
      .then((QuerySnapshot querySnapshot) {
        Map<String, String?> tempAssigned = {};
        for (var doc in querySnapshot.docs) {
          tempAssigned[doc['course']] = doc.id;
        }
        setState(() {
          assignedCourseIds = tempAssigned;
        });
      });
  }

  Future<void> _assignOrUpdateCourse() async {
    if (selectedCourse != null && day != null && startTime != null && endTime != null && room != null) {
      String? docId = assignedCourseIds[selectedCourse];
      Map<String, dynamic> data = {
        'teacherId': widget.teacherId,
        'course': selectedCourse,
        'day': day,
        'startTime': startTime!.format(context),
        'endTime': endTime!.format(context),
        'room': room,
      };

      if (docId != null) {

        await FirebaseFirestore.instance.collection('teacherCourses').doc(docId).update(data);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Course updated successfully")));
      } else {

        await FirebaseFirestore.instance.collection('teacherCourses').add(data);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Course assigned successfully")));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please fill out all fields")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Assign Courses to ${widget.teacherName}'),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Course:", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              DropdownButton<String>(
                isExpanded: true,
                value: selectedCourse,
                onChanged: (newValue) {
                  setState(() {
                    selectedCourse = newValue;
                  });
                },
                items: courseNames.expand((element) => element).map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              Text("Day:", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              DropdownButton<String>(
                isExpanded: true,
                value: day,
                onChanged: (newValue) {
                  setState(() {
                    day = newValue;
                  });
                },
                items: <String>['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              Text("Start Time:", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ListTile(
                title: Text(startTime == null ? "Select Start Time" : "Start Time: ${startTime!.format(context)}"),
                onTap: () async {
                  TimeOfDay? newTime = await showTimePicker(
                    context: context,
                    initialTime: startTime ?? TimeOfDay(hour: 9, minute: 0),
                  );
                  if (newTime != null) {
                    setState(() {
                      startTime = newTime;
                    });
                  }
                },
              ),
              SizedBox(height: 20),
              Text("End Time:", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ListTile(
                title: Text(endTime == null ? "Select End Time" : "End Time: ${endTime!.format(context)}"),
                onTap: () async {
                  TimeOfDay? newTime = await showTimePicker(
                    context: context,
                    initialTime: endTime ?? TimeOfDay(hour: 10, minute: 0),
                  );
                  if (newTime != null) {
                    setState(() {
                      endTime = newTime;
                    });
                  }
                },
              ),
              SizedBox(height: 20),
              Text("Room Number:", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              TextField(
                decoration: InputDecoration(
                  labelText: "Enter Room Number",
                  border: OutlineInputBorder(),
                ),
                onChanged: (newValue) {
                  room = newValue;
                },
              ),
              SizedBox(height: 20),
              Center(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,  
                    backgroundColor: Colors.deepPurple,  
                  ),
                  onPressed: _assignOrUpdateCourse,
                  child: Text("Assign Course"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
