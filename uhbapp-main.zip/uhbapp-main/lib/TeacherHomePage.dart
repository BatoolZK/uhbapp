import 'package:flutter/material.dart';
import 'package:uhbapp/AcademicRecordsPage.dart';
import 'package:uhbapp/AdsDetailPage.dart';
import 'package:uhbapp/DiscountsDetailPage.dart';
import 'package:uhbapp/EventsDetailPage.dart';
import 'package:uhbapp/ProfilePage.dart';
import 'package:uhbapp/SchedulePage.dart';
import 'package:uhbapp/SchedulePage_S.dart';
import 'package:uhbapp/ServicesPage.dart';
import 'package:uhbapp/ServicesTeacherPage.dart';

 
class TeacherHomePage extends StatefulWidget {
  @override
  _TeacherHomePageState createState() => _TeacherHomePageState();
}

class _TeacherHomePageState extends State<TeacherHomePage> {
  int _currentIndex = 0;

  List<Widget> _pages = [
    HomeDetailPage(),
    ServicesTeacherPage(),
    ProfilePage()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.apps),
            label: 'Services',
          ),
           
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        selectedItemColor: Colors.deepOrange,
        unselectedItemColor: Colors.grey,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        elevation: 10.0,
      ),
  
    );
  }
}
 
class HomeDetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Details'),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          child: Column(
            children: [
              _buildClickableImage(context, 'Advertisements', 'assets/images/addslogo.png', AdsDetailPage()),
              _buildClickableImage(context, 'Events', 'assets/images/events.webp', EventsDetailPage()),
              _buildClickableImage(context, 'Student Discounts', 'assets/images/discount.png', DiscountsDetailPage()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildClickableImage(BuildContext context, String title, String imagePath, Widget destination) {
    return InkWell(
      onTap: () {
        Navigator.of(context).push(MaterialPageRoute(builder: (context) => destination));
      },
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Container(
              constraints: BoxConstraints(
                maxHeight: 200,  
              ),
              child: Image.asset(imagePath, width: MediaQuery.of(context).size.width, fit: BoxFit.cover),
            ),
          ),
          Text(
            title,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
          ),
        ],
      ),
    );
  }
}
