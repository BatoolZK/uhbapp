import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TeacherSchedulePage extends StatefulWidget {
  @override
  _TeacherSchedulePageState createState() => _TeacherSchedulePageState();
}

class _TeacherSchedulePageState extends State<TeacherSchedulePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<Map<String, dynamic>> courses = [];

  @override
  void initState() {
    super.initState();
    fetchTeacherCourses();
  }

  Future<void> fetchTeacherCourses() async {
    User? user = _auth.currentUser;
    if (user != null) {
      var coursesSnapshot = await _firestore
          .collection('courses')
          .where('instructor', isEqualTo: user.email)
          .get();

      List<Map<String, dynamic>> tempCourses = [];
      for (var doc in coursesSnapshot.docs) {
        tempCourses.add(doc.data());
      }

      setState(() {
        courses = tempCourses;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Teacher Schedule'),
      ),
      body: courses.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: courses.length,
              itemBuilder: (context, index) {
                var course = courses[index];
                return Card(
                  child: ListTile(
                    title: Text(course['name']),
                    subtitle: Text('Code: ${course['code']}\nDay: ${course['day']}\nTime: ${course['hour']}:00\nDuration: ${course['duration']} hour(s)'),
                    isThreeLine: true,
                  ),
                );
              },
            ),
    );
  }
}
