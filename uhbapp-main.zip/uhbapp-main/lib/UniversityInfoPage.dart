import 'package:flutter/material.dart';

class UniversityInfoPage extends StatefulWidget {
  @override
  _UniversityInfoPageState createState() => _UniversityInfoPageState();
}

class _UniversityInfoPageState extends State<UniversityInfoPage> {
  List<Item> _data = [
    Item(
      headerValue: 'Academic Policies',
      expandedValue: 'Includes details on grading, examinations, and academic integrity. For more comprehensive information, please refer to the university\'s academic handbook available on our website.',
      icon: Icons.school,
    ),
    Item(
      headerValue: 'Student Resources',
      expandedValue: 'Find information about library access, tutoring services, counseling, and career development opportunities. Visit the Student Services section on our website for more details.',
      icon: Icons.local_library,
    ),
    Item(
      headerValue: 'Important Contacts',
      expandedValue: 'For inquiries or assistance, please contact: \n- Admissions Office: +966 13 860 0000\n- Student Affairs: +966 13 860 0001\n- IT Support: support@uhb.edu.sa',
      icon: Icons.contact_phone,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("University of Hafr Al Batin Information"),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(8),
          child: _buildPanel(),
        ),
      ),
    );
  }

  Widget _buildPanel() {
    return ExpansionPanelList.radio(
      elevation: 1,
      expandedHeaderPadding: EdgeInsets.symmetric(vertical: 8),
      children: _data.map<ExpansionPanelRadio>((Item item) {
        return ExpansionPanelRadio(
          value: item.headerValue,
          canTapOnHeader: true,
          headerBuilder: (BuildContext context, bool isExpanded) {
            return ListTile(
              leading: Icon(item.icon, color: Colors.deepPurple),
              title: Text(item.headerValue, style: TextStyle(fontWeight: FontWeight.bold)),
            );
          },
          body: ListTile(
              title: Text(item.expandedValue,
                  style: TextStyle(fontSize: 14, height: 1.5)),
              subtitle: item.headerValue == 'Important Contacts'
                  ? TextButton.icon(
                      onPressed: () {},
                      icon: Icon(Icons.mail_outline, size: 18, color: Colors.deepPurple),
                      label: Text('Send Email', style: TextStyle(color: Colors.deepPurple)),
                    )
                  : null),
        );
      }).toList(),
    );
  }
}

class Item {
  Item({
    required this.expandedValue,
    required this.headerValue,
    required this.icon,
    this.isExpanded = true,
  });

  String expandedValue;
  String headerValue;
  IconData icon;
  bool isExpanded;
}
