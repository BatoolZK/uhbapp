import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ExcusesPage extends StatefulWidget {
  @override
  _ExcusesPageState createState() => _ExcusesPageState();
}

class _ExcusesPageState extends State<ExcusesPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<Excuse>> getExcusesStream() {
    String? userId = _auth.currentUser?.uid;
    return _firestore
        .collection('excuses')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => Excuse.fromDocument(doc)).toList());
  }

  void deleteExcuse(String docId) async {
    await _firestore.collection('excuses').doc(docId).delete();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Excuse deleted successfully')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Excuses'),
        backgroundColor: Colors.deepPurple,
      ),
      body: StreamBuilder<List<Excuse>>(
        stream: getExcusesStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error loading excuses'));
          } else if (snapshot.data!.isEmpty) {
            return Center(child: Text('No excuses submitted yet'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                Excuse excuse = snapshot.data![index];
                return Card(
                  margin: EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(excuse.courseCode),
                    subtitle: Text(excuse.excuse),
                    trailing: Wrap(
                      spacing: 12,
                      children: <Widget>[
                        Text(excuse.date),

                        if (excuse.approved == null) IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => deleteExcuse(excuse.docId),
                        ),

                        Icon(excuse.approved == true ? Icons.check_circle : Icons.cancel, color: excuse.approved == true ? Colors.green : Colors.grey),
                      ],
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}

class Excuse {
  final String userId;
  final String courseCode;
  final String excuse;
  final String date;
  final bool? approved; 

  final String docId;

  Excuse({required this.userId, required this.courseCode, required this.excuse, required this.date, this.approved, required this.docId});

  factory Excuse.fromDocument(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Excuse(
      userId: data['userId'] ?? '',
      courseCode: data['courseCode'] ?? '',
      excuse: data['excuse'] ?? '',
      date: (data['date'] as Timestamp).toDate().toString(),
      approved: data['approved'] as bool?,  
      docId: doc.id,
    );
  }
}
