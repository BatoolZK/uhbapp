import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uhbapp/ServicesAdminPage.dart';
import 'package:uhbapp/TeacherHomePage.dart';
import 'package:uhbapp/home.dart';
import 'package:uhbapp/login.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // await createStudentAccounts();
  // await addCourses();
  // await createInstructorAccounts();
  // await createAdminAccount();
  runApp(MyApp());
}

Future<void> createStudentAccounts() async {
  final FirebaseAuth auth = FirebaseAuth.instance;
  const defaultPassword = "123456";

  final List<Map<String, String>> students = [
    {
      "firstName": "Batool",
      "lastName": "Al-alwan",
      "email": "student1@uhb.com",
      "studentID": "2201004063"
    },
    {
      "firstName": "Manar",
      "lastName": "Al-ojyan",
      "email": "student2@uhb.com",
      "studentID": "2201002945"
    },
    {
      "firstName": "Noor",
      "lastName": "Alsebaa",
      "email": "student3@uhb.com",
      "studentID": "2201002664"
    },
    {
      "firstName": "Heba",
      "lastName": "Shwaihee",
      "email": "student4@uhb.com",
      "studentID": "2201002669"
    },
    {
      "firstName": "Zahra",
      "lastName": "Alabdulal",
      "email": "student5@uhb.com",
      "studentID": "2201001756"
    },
    {
      "firstName": "Rudaynah",
      "lastName": "Alswai",
      "email": "student6@uhb.com",
      "studentID": "2191003329"
    },
  ];

  for (final student in students) {
    try {
      UserCredential userCredential = await auth.createUserWithEmailAndPassword(
        email: student["email"]!,
        password: defaultPassword,
      );

      await FirebaseFirestore.instance
          .collection('users')
          .doc(userCredential.user!.uid)
          .set({
        'firstName': student["firstName"],
        'lastName': student["lastName"],
        'email': student["email"],
        'studentID': student["studentID"],
        'type': 'student',
      });
    } catch (e) {
      print('Error creating user ${student["email"]}: $e');
    }
  }
}

Future<void> addCourses() async {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  final List<List<List<String>>> courseNames = [
    [
      ["MATH 101", "Calculus I"],
      ["PHYS 101", "General Physics I"],
      ["ENGL 101", "An Introduction to Academic Discourse"],
      ["CHEM 111", "General Chemistry I"],
      ["IAS 111", "Belief and Its Consequences"],
      ["PE 101", "Health and Physical Education I"]
    ],
    [
      ["MATH 102", "Calculus II"],
      ["PHYS 102", "General Physics II"],
      ["ENGL 102", "Introduction to Report Writing"],
      ["CSE 102", "Introduction to Computing I"],
      ["IAS 101", "Practical Grammar"],
      ["PE 102", "Health and Physical Education II"]
    ],
    [
      ["EE 200", "Digital Logic Circuit Design"],
      ["CSE 201", "Introduction to Computing II"],
      ["ENGL 214", "Academic and Professional Communication"],
      ["MATH 201", "Calculus III"],
      ["IAS 212", "Professional Ethics"]
    ],
    [
      ["SWE 205", "Introduction to Software Engineering"],
      ["SWE 215", "Software Requirements Engineering"],
      ["CSE 202", "Data Structures"],
      ["BIOL 233", "Biology for Engineers"],
      ["CSE 253", "Discrete Structures"]
    ],
    [
      ["SWE 326", "Software Testing and Quality Assurance"],
      ["CSE 333", "Computer Architecture and Assembly Language"],
      ["CSE 324", "Database Systems"],
      ["SWE 316", "Software Design and Architecture"],
      ["IAS 201", "Writing for Professional Needs"]
    ],
    [
      ["STAT 319", "Probability and Statistics for Engineers and Scientists"],
      ["CSE 343", "Fundamentals of Computer Networks"],
      ["CSE 353", "Design and Analysis of Algorithms"],
      ["SWE 312", "User Interface Design"],
      ["SWE 387", "Software Project Management"],
      ["IAS 301", "Oral Communication Skills"],
      ["SWE 399", "Summer Training"]
    ],
    [
      ["XXXXXX", "Major Elective I"],
      ["SWE 417", "Software Engineering Project I"],
      ["CSE 335", "Introduction to Automata and Formal Languages"],
      ["CSE 309", "Professionalism and Ethics"],
      ["SWE 363", "Web Engineering and Development"],
      ["IAS 322", "Human Rights in Islam"]
    ],
    [
      ["CSE 401", "Operating Systems"],
      ["XXXXXX", "Major Elective II"],
      ["XXXXXX", "Free Elective"],
      ["SWE 418", "Software Engineering Project II"],
      ["GSXXX", "General Studies Elective"]
    ],
  ];

  final Map<String, String> courseInstructors = {
    "MATH 101": "max.sivester.oumbaba@uhb.com",
    "PHYS 101": "default1@uhb.com",
    "ENGL 101": "suzan.farouq.hussein@uhb.com",
    "CHEM 111": "default2@uhb.com",
    "IAS 111": "default3@uhb.com",
    "PE 101": "default4@uhb.com",
    "MATH 102": "somaya.elmonji.saleh@uhb.com",
    "PHYS 102": "default5@uhb.com",
    "ENGL 102": "suha.amin.fakhouri@uhb.com",
    "CSE 102": "default6@uhb.com",
    "IAS 101": "default7@uhb.com",
    "PE 102": "default8@uhb.com",
    "EE 200": "bander.alshammari@uhb.com",
    "CSE 201": "farhat.naureen.memon@uhb.com",
    "ENGL 214": "mastoura.mohamed.daoud@uhb.com",
    "MATH 201": "default9@uhb.com",
    "IAS 212": "zaina.mohamed.alkuhtani@uhb.com",
    "SWE 205": "mohammed.abdul.moid.qureshi@uhb.com",
    "SWE 215": "ghada.bilal@uhb.com",
    "CSE 202": "enas.mohamed.abdelrazak@uhb.com",
    "BIOL 233": "saima.feroz@uhb.com",
    "CSE 253": "maryam.mohamed.aldabel@uhb.com",
    "SWE 326": "amal.ahmed.alfadhl@uhb.com",
    "CSE 333": "eman.ibrahim.almahdabi@uhb.com",
    "CSE 324": "mai.abdullah.alotaibi@uhb.com",
    "SWE 316": "amina.abiola.ajibola@uhb.com",
    "IAS 201": "nawal.zayed.almotairi@uhb.com",
    "STAT 319": "nada.mohamed.alamin@uhb.com",
    "CSE 343": "mai.abdullah.alotaibi@uhb.com",
    "CSE 353": "asma.abd.alsufyani@uhb.com",
    "SWE 312": "amal.ahmed.alfadhl@uhb.com",
    "SWE 387": "noura.rashed.alkhater@uhb.com",
    "IAS 301": "seita.ateeq.alfahmi@uhb.com",
    "SWE 399": "abdullah.alshammari@uhb.com",
    "XXXXXX": "default10@uhb.com",
    "SWE 417": "bassema.abdelmaged.omar@uhb.com",
    "CSE 335": "walla.mohyie.alshemy@uhb.com",
    "CSE 309": "mimouna.salah.aldoiban@uhb.com",
    "SWE 363": "manal.ibrahim.hassan@uhb.com",
    "IAS 322": "refaa.ahmed.aldosari@uhb.com",
    "CSE 401": "selma.einarsir.abdella@uhb.com",
  };

  final List<String> days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"];
  final List<int> hours = [8, 9, 10, 11, 12, 13, 14, 15];

  Map<String, Map<int, String>> schedule = {
    for (var day in days) day: {for (var hour in hours) hour: ""}
  };

  Map<String, List<String>> instructorSchedule = {
    for (var instructor in courseInstructors.values) instructor: []
  };

  bool isSlotAvailable(String day, int hour, int duration, String instructor) {
    for (int i = 0; i < duration; i++) {
      if (schedule[day]![hour + i]!.isNotEmpty || instructorSchedule[instructor]!.contains('$day-$hour')) {
        return false;
      }
    }
    return true;
  }

  void assignSlot(String courseCode, int duration, String instructor) {
    List<String> assignedDays = [];
    int maxSlotsPerWeek = 3;

    for (var day in days) {
      if (assignedDays.length >= maxSlotsPerWeek) break;
      for (var hour in hours) {
        if (hour + duration <= 16 && isSlotAvailable(day, hour, duration, instructor)) {
          for (int i = 0; i < duration; i++) {
            schedule[day]![hour + i] = courseCode;
            instructorSchedule[instructor]!.add('$day-$hour');
          }
          assignedDays.add(day);
          break;
        }
      }
    }
  }

  for (int levelIndex = 0; levelIndex < courseNames.length; levelIndex++) {
    var level = courseNames[levelIndex];
    for (var course in level) {
      var existingCourses = await firestore.collection('courses').where('code', isEqualTo: course[0]).limit(1).get();

      if (existingCourses.docs.isEmpty) {
        String instructor = courseInstructors[course[0]] ?? "default@uhb.com";

        // Assign time slot
        int duration = (course[0].contains("LAB") || course[0].contains("Lecture")) ? 2 : 1;
        assignSlot(course[0], duration, instructor);

        List<Map<String, dynamic>> courseSchedules = [];
        for (var day in days) {
          for (var hour in hours) {
            if (schedule[day]![hour] == course[0]) {
              courseSchedules.add({
                'day': day,
                'hour': hour,
                'duration': duration,
              });
              if (courseSchedules.length == 3) break;
            }
          }
          if (courseSchedules.length == 3) break;
        }

        for (var courseSchedule in courseSchedules) {
          await firestore.collection('courses').add({
            'code': course[0],
            'name': course[1],
            'level': levelIndex + 1,
            'instructor': instructor,
            'day': courseSchedule['day'],
            'hour': courseSchedule['hour'],
            'duration': courseSchedule['duration'],
          }).catchError((e) {
            print('Error adding course ${course[0]}: $e');
          });
        }
      }
    }
  }
}

Future<void> createInstructorAccounts() async {
  final FirebaseAuth auth = FirebaseAuth.instance;

  const defaultPassword = "123456";

  final List<Map<String, String>> instructors = [
    {"firstName": "Saima", "lastName": "Feroz", "email": "saima.feroz@uhb.com"},
    {
      "firstName": "Farhat",
      "lastName": "Naureen Memon",
      "email": "farhat.naureen.memon@uhb.com"
    },
    {
      "firstName": "Selma",
      "lastName": "Einarsir Abdella",
      "email": "selma.einarsir.abdella@uhb.com"
    },
    {
      "firstName": "Bander",
      "lastName": "Alshammari",
      "email": "bander.alshammari@uhb.com"
    },
    {
      "firstName": "Suzan",
      "lastName": "Farouq Hussein",
      "email": "suzan.farouq.hussein@uhb.com"
    },
    {
      "firstName": "Suha",
      "lastName": "Amin Fakhouri",
      "email": "suha.amin.fakhouri@uhb.com"
    },
    {
      "firstName": "Mohammed",
      "lastName": "Abdul Moid Qureshi",
      "email": "mohammed.abdul.moid.qureshi@uhb.com"
    },
    {
      "firstName": "Mashael",
      "lastName": "Aldhafeeri",
      "email": "mashael.aldhafeeri@uhb.com"
    },
    {"firstName": "AMNA", "lastName": "KHAN", "email": "amna.khan@uhb.com"},
    {
      "firstName": "Dr.",
      "lastName": "Abdullah Alshammari",
      "email": "abdullah.alshammari@uhb.com"
    },
    {
      "firstName": "default1",
      "lastName": "Instructor",
      "email": "default1@uhb.com"
    },
    {
      "firstName": "default2",
      "lastName": "Instructor",
      "email": "default2@uhb.com"
    },
    {
      "firstName": "default3",
      "lastName": "Instructor",
      "email": "default3@uhb.com"
    },
    {
      "firstName": "default4",
      "lastName": "Instructor",
      "email": "default4@uhb.com"
    },
    {
      "firstName": "default5",
      "lastName": "Instructor",
      "email": "default5@uhb.com"
    },
    {
      "firstName": "default6",
      "lastName": "Instructor",
      "email": "default6@uhb.com"
    },
    {
      "firstName": "default7",
      "lastName": "Instructor",
      "email": "default7@uhb.com"
    },
    {
      "firstName": "default8",
      "lastName": "Instructor",
      "email": "default8@uhb.com"
    },
    {
      "firstName": "default9",
      "lastName": "Instructor",
      "email": "default9@uhb.com"
    },
    {
      "firstName": "default10",
      "lastName": "Instructor",
      "email": "default10@uhb.com"
    },
    {"firstName": "Ghada", "lastName": "Bilal", "email": "ghada.bilal@uhb.com"},
    {
      "firstName": "Amina",
      "lastName": "Abi Ola Ajibola",
      "email": "amina.abiola.ajibola@uhb.com"
    },
    {
      "firstName": "Noura",
      "lastName": "Rashed Alkater",
      "email": "noura.rashed.alkater@uhb.com"
    },
    {
      "firstName": "Seita",
      "lastName": "Ateeq Al Fahmi",
      "email": "seita.ateeq.alfahmi@uhb.com"
    },
    {
      "firstName": "Refaa",
      "lastName": "Ahmed Al Dosari",
      "email": "refaa.ahmed.aldosari@uhb.com"
    },
    {
      "firstName": "Lubna",
      "lastName": "Mohamed Bou Aziz",
      "email": "lubna.mohamed.bouaziz@uhb.com"
    },
    {
      "firstName": "Somaya",
      "lastName": "El Monji Saleh",
      "email": "somaya.elmonji.saleh@uhb.com"
    },
    {
      "firstName": "Max",
      "lastName": "Sivester Oumbaba",
      "email": "max.sivester.oumbaba@uhb.com"
    },
    {
      "firstName": "Mastoura",
      "lastName": "Mohamed Daoud",
      "email": "mastoura.mohamed.daoud@uhb.com"
    },
    {
      "firstName": "Maryam",
      "lastName": "Mohamed Al Dabel",
      "email": "maryam.mohamed.aldabel@uhb.com"
    },
    {
      "firstName": "Mimouna",
      "lastName": "Salah Al Doiban",
      "email": "mimouna.salah.aldoiban@uhb.com"
    },
    {
      "firstName": "Mai",
      "lastName": "Abdullah Al Otaibi",
      "email": "mai.abdullah.alotaibi@uhb.com"
    },
    {
      "firstName": "Eman",
      "lastName": "Ibrahim Al Mahdabi",
      "email": "eman.ibrahim.almahdabi@uhb.com"
    },
    {
      "firstName": "Walla",
      "lastName": "Mohyie Al Shemy",
      "email": "walla.mohyie.alshemy@uhb.com"
    },
    {
      "firstName": "Asma",
      "lastName": "Abad Al Sufyani",
      "email": "asma.abd.alsufyani@uhb.com"
    },
    {
      "firstName": "Nada",
      "lastName": "Mohamed Al Amin",
      "email": "nada.mohamed.alamin@uhb.com"
    },
    {
      "firstName": "Nawal",
      "lastName": "Zayed Al Motairi",
      "email": "nawal.zayed.almotairi@uhb.com"
    },
    {
      "firstName": "Amal",
      "lastName": "Ahmed Al Fadhl",
      "email": "amal.ahmed.alfadhl@uhb.com"
    },
    {
      "firstName": "Zaina",
      "lastName": "Mohamed Al Kuhtani",
      "email": "zaina.mohamed.alkuhtani@uhb.com"
    },
  ];
  for (final instructor in instructors) {
    try {
      UserCredential userCredential;
      try {
        userCredential = await auth.createUserWithEmailAndPassword(
          email: instructor["email"]!,
          password: defaultPassword,
        );
      } catch (e) {
        // If the user already exists, get the user by email
        userCredential = await auth.signInWithEmailAndPassword(
          email: instructor["email"]!,
          password: defaultPassword,
        );
      }

      // Add instructor details to Firestore if not already added
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userCredential.user!.uid)
          .get();
      if (!doc.exists) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(userCredential.user!.uid)
            .set({
          'firstName': instructor["firstName"],
          'lastName': instructor["lastName"],
          'email': instructor["email"],
          'type': 'teacher',
        });
      }
    } catch (e) {
      print('Error creating or getting user ${instructor["email"]}: $e');
    }
  }
}

Future<void> createAdminAccount() async {
  final FirebaseAuth auth = FirebaseAuth.instance;

  const defaultPassword = "123456";

  const admin = {
    "firstName": "Admin",
    "lastName": "User",
    "email": "admin@admin.com"
  };

  try {
    UserCredential userCredential;
    try {
      userCredential = await auth.createUserWithEmailAndPassword(
        email: admin["email"]!,
        password: defaultPassword,
      );
    } catch (e) {
       userCredential = await auth.signInWithEmailAndPassword(
        email: admin["email"]!,
        password: defaultPassword,
      );
    }

     DocumentSnapshot doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(userCredential.user!.uid)
        .get();
    if (!doc.exists) {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userCredential.user!.uid)
          .set({
        'firstName': admin["firstName"],
        'lastName': admin["lastName"],
        'email': admin["email"],
        'type': 'admin',
      });
    }
  } catch (e) {
    print('Error creating or getting admin user ${admin["email"]}: $e');
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'University Hub',
      debugShowCheckedModeBanner: false,
      home: MainScreen(),
    );
  }
}

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          User? user = snapshot.data;
          if (user == null) {
            return LoginPage();
          } else {
            return FutureBuilder<DocumentSnapshot>(
              future: FirebaseFirestore.instance
                  .collection('users')
                  .doc(user.uid)
                  .get(),
              builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  if (snapshot.data != null && snapshot.data!.exists) {
                    Map<String, dynamic> userData =
                        snapshot.data!.data() as Map<String, dynamic>;
                    if (userData['type'] == 'admin') {
                      return ServicesAdminPage();
                    } 
                    
                    else if (userData['type'] == 'teacher') {
                      return TeacherHomePage();
                    } 
                     else if (userData['type'] == 'student') {
                      return HomePage();
                    } 
                    
                    else {
                      return HomePage();
                    }

                  } else {
                    return LoginPage();
                  }
                } else {
                  return Scaffold(
                    body: Center(child: CircularProgressIndicator()),
                  );
                }
              },
            );
          }
        } else {
          return Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
      },
    );
  }
}
