import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:uhbapp/ServicesAdminPage.dart';
import 'package:uhbapp/TeacherHomePage.dart';
import 'package:uhbapp/home.dart';
import 'package:uhbapp/login.dart';

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          User? user = snapshot.data;
          if (user == null) {
            return LoginPage();
          } else {
            return FutureBuilder<DocumentSnapshot>(
              future: FirebaseFirestore.instance
                  .collection('users')
                  .doc(user.uid)
                  .get(),
              builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  if (snapshot.hasError) {
                    print('Error fetching user data: ${snapshot.error}');
                    return LoginPage();
                  }

                  if (snapshot.data != null && snapshot.data!.exists) {
                    Map<String, dynamic> userData = snapshot.data!.data() as Map<String, dynamic>;
                    print('User data: $userData');

                    String userType = userData['type'];
                    print('User type: $userType');

                    if (userType == 'admin') {
                      return ServicesAdminPage();
                    } else if (userType == 'teacher') {
                      return TeacherHomePage();
                    } else if (userType == 'student') {
                      return HomePage();
                    } else {
                      print('Unknown user type: $userType');
                      return LoginPage();
                    }
                  } else {
                    print('User document not found or has no data');
                    return LoginPage();
                  }
                } else {
                  print('Fetching user document...');
                  return Scaffold(
                    body: Center(child: CircularProgressIndicator()),
                  );
                }
              },
            );
          }
        } else {
          print('Waiting for auth state to change...');
          return Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
      },
    );
  }
}
