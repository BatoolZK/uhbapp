import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MoreDetailsPage extends StatelessWidget {
  final String eventId;

  MoreDetailsPage({required this.eventId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Event Details'),
        backgroundColor: Colors.green,
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('events').doc(eventId).get(),
        builder: (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.hasError) {
            return Text("Something went wrong");
          }

          if (snapshot.hasData && !snapshot.data!.exists) {
            return Text("Document does not exist");
          }

          if (snapshot.connectionState == ConnectionState.done) {
            Map<String, dynamic> data = snapshot.data!.data() as Map<String, dynamic>;
            return SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  data['imageUrl'] != null
                    ? Image.network(data['imageUrl'], width: MediaQuery.of(context).size.width, height: 250, fit: BoxFit.cover)
                    : Container(height: 250, color: Colors.grey.shade300, alignment: Alignment.center, child: Text('No Image Available')),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(data['name'], style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                        SizedBox(height: 8),
                        Text("Location: ${data['location']}", style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic)),
                        SizedBox(height: 8),
                        Text("Starts: ${data['startDate']}", style: TextStyle(fontSize: 16)),
                        SizedBox(height: 8),
                        Text("Ends: ${data['endDate']}", style: TextStyle(fontSize: 16)),
                        SizedBox(height: 16),
                        Text(data['description'], style: TextStyle(fontSize: 18)),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }

          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }
}
